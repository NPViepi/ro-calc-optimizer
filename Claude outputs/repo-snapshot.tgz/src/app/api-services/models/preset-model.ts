import type { SkillFormulaVersion } from '../../skills/skill-formula-version';

export interface PresetModel {
  skillFormulaVersion?: SkillFormulaVersion;
  class: number;
  level: number;
  jobLevel: number;

  /** Character appearance for the paper-doll (replay import). 0 = female, 1 = male. */
  sex?: number;
  hairStyle?: number;
  hairColor?: number;
  clothesColor?: number;
  str: number;
  jobStr: number;
  agi: number;
  jobAgi: number;
  vit: number;
  jobVit: number;
  int: number;
  jobInt: number;
  dex: number;
  jobDex: number;
  luk: number;
  jobLuk: number;
  selectedAtkSkill: string;
  /** The attack rotation (src/app/core/rotation.ts). Absent on presets saved before
   *  rotations existed, and dropped from share tokens when it is just
   *  `[selectedAtkSkill]` — `normalizeRotation` rebuilds it either way. */
  rotation?: string[];
  skillStacks?: Record<string, number>;
  /** Configurable choices in the Auto-conjuração panel, keyed by slot. */
  autoCastSelections?: { autoSpell?: number; plagiarism?: number; reproduce?: number };
  rawOptionTxts: any[];
  /** Per-slot highlight colours (src/app/core/slot-colors.ts). Absent on presets
   *  saved before the feature, and dropped from a share token when nothing is marked. */
  slotColors?: Record<string, string>;
  propertyAtk: string;

  ammo: number;

  weapon: number;
  weaponRefine: number;
  weaponCard1: number;
  weaponCard2: number;
  weaponCard3: number;
  weaponCard4: number;
  weaponEnchant0: number;
  weaponEnchant1: number;
  weaponEnchant2: number;
  weaponEnchant3: number;

  leftWeapon: number;
  leftWeaponRefine: number;
  leftWeaponCard1: number;
  leftWeaponCard2: number;
  leftWeaponCard3: number;
  leftWeaponCard4: number;
  leftWeaponEnchant0: number;
  leftWeaponEnchant1: number;
  leftWeaponEnchant2: number;
  leftWeaponEnchant3: number;

  shield: number;
  shieldRefine: number;
  shieldCard: number;
  shieldEnchant1: number;
  shieldEnchant2: number;
  shieldEnchant3: number;

  headUpper: number;
  headUpperRefine: number;
  headUpperCard: number;
  headUpperEnchant1: number;
  headUpperEnchant2: number;
  headUpperEnchant3: number;
  headMiddle: number;
  headMiddleCard: number;
  headMiddleEnchant1: number;
  headMiddleEnchant2: number;
  headMiddleEnchant3: number;
  headLower: number;
  headLowerCard: number;
  headLowerEnchant1: number;
  headLowerEnchant2: number;
  headLowerEnchant3: number;

  armor: number;
  armorRefine: number;
  armorCard: number;
  armorEnchant1: number;
  armorEnchant2: number;
  armorEnchant3: number;
  garment: number;
  garmentRefine: number;
  garmentCard: number;
  garmentEnchant1: number;
  garmentEnchant2: number;
  garmentEnchant3: number;
  boot: number;
  bootRefine: number;
  bootCard: number;
  bootEnchant1: number;
  bootEnchant2: number;
  bootEnchant3: number;
  accLeft: number;
  accLeftRefine: number;
  accLeftCard: number;
  accLeftEnchant1: number;
  accLeftEnchant2: number;
  accLeftEnchant3: number;
  accRight: number;
  accRightRefine: number;
  accRightCard: number;
  accRightEnchant1: number;
  accRightEnchant2: number;
  accRightEnchant3: number;

  pet: number;

  costumeEnchantUpper: number;
  costumeEnchantMiddle: number;
  costumeEnchantLower: number;
  costumeEnchantGarment: number;
  costumeEnchantGarment4: number;

  shadowWeapon: number;
  shadowWeaponRefine: number;
  shadowWeaponEnchant1: number;
  shadowWeaponEnchant2: number;
  shadowWeaponEnchant3: number;
  shadowArmor: number;
  shadowArmorRefine: number;
  shadowArmorEnchant1: number;
  shadowArmorEnchant2: number;
  shadowArmorEnchant3: number;
  shadowShield: number;
  shadowShieldRefine: number;
  shadowShieldEnchant1: number;
  shadowShieldEnchant2: number;
  shadowShieldEnchant3: number;
  shadowBoot: number;
  shadowBootRefine: number;
  shadowBootEnchant1: number;
  shadowBootEnchant2: number;
  shadowBootEnchant3: number;
  shadowEarring: number;
  shadowEarringRefine: number;
  shadowEarringEnchant1: number;
  shadowEarringEnchant2: number;
  shadowEarringEnchant3: number;
  shadowPendant: number;
  shadowPendantRefine: number;
  shadowPendantEnchant1: number;
  shadowPendantEnchant2: number;
  shadowPendantEnchant3: number;

  skillBuffMap: { [key: string]: number; };
  skillBuffs: number[];
  activeSkillMap: { [key: string]: number; };
  activeSkills: number[];
  passiveSkillMap: { [key: string]: number; };
  passiveSkills: number[];
  consumables: any[];
  consumables2: any[];
  aspdPotion: number;
  aspdPotions: any[];
}
