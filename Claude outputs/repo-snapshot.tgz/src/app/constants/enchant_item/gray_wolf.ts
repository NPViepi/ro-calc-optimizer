import { aspd13, aspd15, ea13, ea15, ef13, ef15, em13, em15, fatal13, fatal14, sp13, sp15 } from "./_basic";

const baseState13 = [
  'Wolf_Orb_Str_1',
  'Wolf_Orb_Str_2',
  'Wolf_Orb_Str_3',
  'Wolf_Orb_Dex_1',
  'Wolf_Orb_Dex_2',
  'Wolf_Orb_Dex_3',
  'Wolf_Orb_Agi_1',
  'Wolf_Orb_Agi_2',
  'Wolf_Orb_Agi_3',
  'Wolf_Orb_Int_1',
  'Wolf_Orb_Int_2',
  'Wolf_Orb_Int_3',
  'Wolf_Orb_Vit_1',
  'Wolf_Orb_Vit_2',
  'Wolf_Orb_Vit_3',
  'Wolf_Orb_luk_1',
  'Wolf_Orb_luk_2',
  'Wolf_Orb_luk_3',
];

export const grayWolfArmor_slot4 = [
  'Wolf_Orb_Str_1',
  'Wolf_Orb_Str_2',
  'Wolf_Orb_Dex_1',
  'Wolf_Orb_Dex_2',
  'Wolf_Orb_Agi_1',
  'Wolf_Orb_Agi_2',
  'Wolf_Orb_Int_1',
  'Wolf_Orb_Int_2',
  'Wolf_Orb_Vit_1',
  'Wolf_Orb_Vit_2',
  'Wolf_Orb_luk_1',
  'Wolf_Orb_luk_2',
  'Wolf_Orb_Def_1',
  'Wolf_Orb_Def_2',
  'Wolf_Orb_Mdef_1',
  'Wolf_Orb_Mdef_2',
  'Wolf_Orb_Ran_1',
  'Wolf_Orb_Ran_2',
  'Wolf_Orb_War_1',
  'Wolf_Orb_War_2',
  'Wolf_Orb_Mag_1',
  'Wolf_Orb_Mag_2',
];
export const grayWolfArmor_slot3 = [
  ...baseState13,
  'Wolf_Orb_Def_1',
  'Wolf_Orb_Def_2',
  'Wolf_Orb_Def_3',
  'Wolf_Orb_Mdef_1',
  'Wolf_Orb_Mdef_2',
  'Wolf_Orb_Mdef_3',
  'Wolf_Orb_Ran_1',
  'Wolf_Orb_Ran_2',
  'Wolf_Orb_Ran_3',
  'Wolf_Orb_War_1',
  'Wolf_Orb_War_2',
  'Wolf_Orb_War_3',
  'Wolf_Orb_Mag_1',
  'Wolf_Orb_Mag_2',
  'Wolf_Orb_Mag_3',
  'Wolf_Orb_S_Delay',
];
export const grayWolfArmor_slot2 = [
  'Wolf_Orb_R_Reject_1',
  'Wolf_Orb_R_Reject_2',
  'Wolf_Orb_R_Reject_3',
  'Wolf_Orb_Force',
  'Wolf_Orb_Skill_1',
  'Wolf_Orb_Skill_2',
  'Wolf_Orb_Skill_3',
  'Wolf_Orb_Skill_4',
  'Wolf_Orb_Skill_5',
  'Wolf_Orb_Skill_6',
  'Wolf_Orb_Skill_7',
  'Wolf_Orb_Skill_8',
  'Wolf_Orb_Skill_9',
  'Wolf_Orb_Skill_10',
  'Wolf_Orb_Skill_11',
  'Wolf_Orb_Skill_12',
  'Wolf_Orb_Skill_13',
  'Wolf_Orb_Skill_14',
  'Wolf_Orb_Skill_15',
  'Wolf_Orb_Skill_16',
  'Wolf_Orb_Skill_17',
  'Wolf_Orb_Skill_18',
  'Wolf_Orb_Skill_19',
  'Wolf_Orb_Skill_20',
  'Wolf_Orb_Skill_21',
  'Wolf_Orb_Skill_22',
  'Wolf_Orb_Skill_23',
  'Wolf_Orb_Skill_24',
  'Wolf_Orb_Skill_25',
  'Wolf_Orb_Skill_26',
  'Wolf_Orb_Skill_27',
  'Wolf_Orb_Skill_28',
  'Wolf_Orb_Skill_29',
  'Wolf_Orb_Skill_30',
  'Wolf_Orb_Skill_31',
  'Wolf_Orb_Skill_32',
  'Wolf_Orb_Skill_33',
  'Wolf_Orb_Skill_34',
  'Wolf_Orb_Skill_35',
  'Wolf_Orb_Skill_36',
  'Wolf_Orb_Skill_37',
  'Wolf_Orb_Skill_38',
  'Wolf_Orb_Skill_39',
  'Wolf_Orb_Skill_40',
  'Wolf_Orb_Skill_41',
  'Wolf_Orb_Skill_42',
  'Wolf_Orb_Skill_43',
  'Wolf_Orb_Skill_44',
  'Wolf_Orb_Skill_45',
  'Wolf_Orb_Skill_46',
  'Wolf_Orb_Skill_47',
  'Wolf_Orb_Skill_48',
  'Wolf_Orb_Skill_49',
  'Wolf_Orb_Skill_50',
  'Wolf_Orb_Skill_51',
];

export const grayWolfGarment_slot4 = [...baseState13];
export const grayWolfGarment_slot3 = [
  'Wolf_Orb_Speed_1',
  'Wolf_Orb_Speed_2',
  'Wolf_Orb_Speed_3',
  'Wolf_Orb_Caster_1',
  'Wolf_Orb_Caster_2',
  'Wolf_Orb_Caster_3',
  'Wolf_Orb_Critical_1',
  'Wolf_Orb_Critical_2',
  'Wolf_Orb_Critical_3',
  'Wolf_Orb_Guide_1',
  'Wolf_Orb_Guide_2',
  'Wolf_Orb_Guide_3',
];
// Slot 1 of the Gray Wolf garments (480090 / 480091). "Total" and "Espelho" only grant
// damage-*taken* resistance, which the engine has no bonus key for, so they contribute
// nothing to the numbers — they are listed anyway so a build can record what is actually
// socketed. Their item.json scripts are deliberately empty; see the Espelho entries.
export const grayWolfGarment_slot2 = [
  'Wolf_Orb_Above_1',
  'Wolf_Orb_Above_2',
  'Wolf_Orb_Above_3',
  'Wolf_Orb_P_Full_1',
  'Wolf_Orb_P_Full_2',
  'Wolf_Orb_P_Full_3',
  'Wolf_Orb_M_Counter_1',
  'Wolf_Orb_M_Counter_2',
  'Wolf_Orb_M_Counter_3',
];

export const grayWolfBoot_slot4 = [
  'Wolf_Orb_Hp_1',
  'Wolf_Orb_Hp_2',
  'Wolf_Orb_Hp_3',
  'Wolf_Orb_Sp_1',
  'Wolf_Orb_Sp_2',
  'Wolf_Orb_Sp_3',
  'Wolf_Orb_Heal_1',
  'Wolf_Orb_Heal_2',
  'Wolf_Orb_Heal_3',
  'Wolf_Orb_Robust_1',
  'Wolf_Orb_Robust_2',
  'Wolf_Orb_Robust_3',
];
export const grayWolfBoot_slot3 = [
  'Wolf_Orb_F_Cast_1',
  'Wolf_Orb_F_Cast_2',
  'Wolf_Orb_F_Cast_3',
  'Wolf_Orb_M_F_1',
  'Wolf_Orb_M_F_2',
  'Wolf_Orb_M_F_3',
  'Wolf_Orb_P_F_1',
  'Wolf_Orb_P_F_2',
  'Wolf_Orb_P_F_3',
];
export const grayWolfBoot_slot2 = ['Wolf_Orb_Un_Vit', 'Wolf_Orb_Sp_Int', 'Wolf_Orb_Fi_Dex', 'Wolf_Orb_Ov_Str', 'Wolf_Orb_Fa_Agi', 'Wolf_Orb_Lu_Luk'];

export const grayWolfAccL_slot4 = [...baseState13];
// Shared head of both Gray Wolf accessory pools — the four damage families and the
// after-cast delay orbs. Slots 1 and 2 diverge only in what follows it.
const grayWolfAccBase = [
  'Wolf_Orb_E_Archer_1',
  'Wolf_Orb_E_Archer_2',
  'Wolf_Orb_E_Archer_3',
  'Wolf_Orb_E_Archer_4',
  'Wolf_Orb_A_Delay_2',
  'Wolf_Orb_A_Delay_3',
  'Wolf_Orb_A_Delay_4',
  'Wolf_Orb_Fatal_1',
  'Wolf_Orb_Fatal_2',
  'Wolf_Orb_Fatal_3',
  'Wolf_Orb_Fatal_4',
  'Wolf_Orb_F_Spirit_1',
  'Wolf_Orb_F_Spirit_2',
  'Wolf_Orb_F_Spirit_3',
  'Wolf_Orb_F_Spirit_4',
  'Wolf_Orb_Spell_1',
  'Wolf_Orb_Spell_2',
  'Wolf_Orb_Spell_3',
  'Wolf_Orb_Spell_4',
];
export const grayWolfAccL_slot3 = [
  ...grayWolfAccBase,
  'Wolf_Orb_HealHP_1',
  'Wolf_Orb_HealHP_2',
  'Wolf_Orb_HealHP_3',
  'Wolf_Orb_HealHP_4',
  'Wolf_Orb_HealSP_1',
  'Wolf_Orb_HealSP_2',
  'Wolf_Orb_HealSP_3',
  'Wolf_Orb_HealSP_4',
];
// Slot 1 differs by side, which bROWiki's single Acessórios table hides — it prints the
// right-hand pool for all four pieces. Hazy Forest keeps the kRO tables apart: the pendant
// and earring (Acc_R) take Drain Life / Magic Healing, the ring and necklace (Acc_L) take
// their SP twins Drain Soul / Magic Soul, each at 3,60% next to All Force.
// @see https://hazyforest.com/enchants:gray_wolf_accessories_right
// @see https://hazyforest.com/enchants:gray_wolf_accessories_left
export const grayWolfAccR_slot2 = [...grayWolfAccBase, 'Wolf_Orb_Life', 'Wolf_Orb_M_Heal', 'Wolf_Orb_A_Force'];
export const grayWolfAccL_slot2 = [...grayWolfAccBase, 'Wolf_Orb_Soul', 'Wolf_Orb_M_Soul', 'Wolf_Orb_A_Force'];

export const grayWolfSoulRing_slot4 = [
  ...em13,
  ...ef13,
  ...ea13,
  ...fatal13,
  ...aspd13,
  ...sp13,
];
export const grayWolfSoulRing_slot3 = [
  ...em15,
  ...ef15,
  ...ea15,
  ...fatal14,
  ...aspd15,
  ...sp15,
];
// export const grayWolfSoulRing_slot2 = [

// ]
