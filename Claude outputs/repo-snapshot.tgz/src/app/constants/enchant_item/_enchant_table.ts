import {
  ASPD,
  Acute,
  Adamatine,
  Agi,
  AtkPercent,
  AttackDelay,
  Cri,
  Dex,
  EA,
  ExpertFighter,
  ExpertMagician,
  FS,
  Fatal,
  Int,
  Luk,
  MSP,
  MagicEess,
  MasterArc,
  MatkPercent,
  Mettle,
  RuneAgi,
  RuneDex,
  RuneInt,
  RuneLuk,
  RuneStr,
  RuneVit,
  Sharp,
  SkillDelay,
  Spell,
  Str,
  Tenacity,
  Vit,
  agi,
  aspd12,
  aspd13,
  aspd14,
  aspd24,
  aspd34,
  atkPer13,
  atkPer23,
  cri510,
  critical23,
  critical24,
  critical34,
  delay12,
  delay13,
  dex,
  ea12,
  ea13,
  ea14,
  ea15,
  ea23,
  ea25,
  ea35,
  ea410,
  ea45,
  ef15,
  em15,
  fatal12,
  fatal13,
  fatal14,
  fatal23,
  fs13,
  fs23,
  fs24,
  fs35,
  fs36,
  fs410,
  fs45,
  fs67,
  fs68,
  illusionDunAcc,
  illusionDunArmor,
  int,
  matk12,
  matk13,
  matkP35,
  mhp34,
  mhp35,
  perfectD12,
  perfectD13,
  sh13,
  sh14,
  sh23,
  sh25,
  sh45,
  shedding12,
  sp14,
  sp23,
  sp25,
  sp34,
  sp45,
  sp46,
  str,
  vit,
} from './_basic';
import { angelRibbonWing3, angelRibbonWing4 } from './angel_ribbon_wing';
import { explorerEngineEnchants, littleGardenSlot4 } from './explorer_league';
import { anni5th } from './anniversary5th';
import { bp7_2, bp7_4 } from './bp7';
import { cirAutumnGarment2, cirAutumnGarment3, cirAutumnGarment4, cirAutumnSummer2, cirAutumnWinter2, cirSpringGarment2, cirSpringGarment3, cirSpringGarment4, manAutumnGarment2, manAutumnGarment3, manAutumnGarment4, manAutumnSummer2, manAutumnWinter2, manSpringGarment2, manSpringGarment3, manSpringGarment4, signetAcc3, signetAcc4, stellarAcc2, stellarAcc3, stellarAcc4 } from './constellation_tower';
import { crafted3, crafted4 } from './crafted_weapon';
import { dimGlaArmor2, dimGlaArmor3, dimGlaArmor4, dimGlaBoot2, dimGlaBoot3, dimGlaBoot4, dimGlaGarment2, dimGlaGarment3, dimGlaGarment4, dimWeapon2, dimWeapon3, dimWeapon4 } from './dim_glacier';
import { dimensionAcc3, dimensionAcc4, dimensionHead2, dimensionHead3, dimensionHead4, dimensionWeapon3, dimensionWeapon4, timeGap3, timeGap4 } from './dimention';
import { droopingLt3, droopingLt4, redBlueLt3, redBlueLt4 } from './drooping_thanatos_lt';
import { furiousHeadUp3, furiousHeadUp4, furiousWeaponUp3, furiousWeaponUp4 } from './furious';
import { gbAcc2, gbAcc3, gbAcc4, gbArmor2, gbArmor3, gbArmor4, gbBoot2, gbBoot3, gbBoot4, gbGarment2, gbGarment3, gbGarment4 } from './gaebolg';
import { glacierAcc2, glacierAcc3, glacierAccL4, glacierAccR4, glacierArmor2, glacierArmor3, glacierArmor4, glacierBoot2, glacierBoot3, glacierBoot4, glacierGarment2, glacierGarment3, glacierGarment4, glacierGuard2, glacierGuard3, glacierGuard4, glacierWea1, glacierWea2, glacierWea3, glacierWea4, issgardCrown2, issgardCrown3, issgardCrown4 } from './glacier';
import {
  grayWolfAccL_slot2,
  grayWolfAccL_slot3,
  grayWolfAccL_slot4,
  grayWolfAccR_slot2,
  grayWolfArmor_slot2,
  grayWolfArmor_slot3,
  grayWolfArmor_slot4,
  grayWolfBoot_slot2,
  grayWolfBoot_slot3,
  grayWolfBoot_slot4,
  grayWolfGarment_slot2,
  grayWolfGarment_slot3,
  grayWolfGarment_slot4,
  grayWolfSoulRing_slot3,
  grayWolfSoulRing_slot4,
} from './gray_wolf';
import { heroBadge2, heroBootLt2, heroBootLt3, heroBootLt4 } from './hero_boots_lt';
import { heroicHead3, heroicHead4 } from './heroic_hairband';
import { madBunnyLt4 } from './mad_bunny_lt';
import { MALANGDO_WEAPON_IDS } from './malangdo_weapons';
import { mShadow3, mShadow4, mShadowABC3, mShadowAM3, mShadowAllClass4, mShadowBIO3, mShadowCAR3, mShadowDK3, mShadowEM3, mShadowHYPER3, mShadowIG3, mShadowIQ3, mShadowMEI3, mShadowNW3, mShadowSA3, mShadowSH3, mShadowSHC3, mShadowSKY3, mShadowSS3, mShadowTVTB3, mShadowWH3 } from './master_shadow';
import { muqaddas3, muqaddas4 } from './muqaddas';
import { nebularShadow2, nebularShadow34 } from './nebula_shadow';
import { nebularPendant3, nebularPendant4 } from './nebular';
import { oasdWeapon3, oasdWeapon4 } from './osad_weapon';
import { plusWeapon3, plusWeapon4 } from './plus_weapon';
import { rockPaperScissor } from './rock_paper_scissor';
import { royalHArmor2, royalHArmor3, royalHArmor4, royalHBoot3, royalHBoot4, royalHGarment3, royalHGarment4 } from './royal_hunting';
import { goodEvilBoot3_ABC, goodEvilBoot3_AG, goodEvilBoot3_BO, goodEvilBoot3_CD, goodEvilBoot3_DK, goodEvilBoot3_EM, goodEvilBoot3_HN, goodEvilBoot3_IG, goodEvilBoot3_IQ, goodEvilBoot3_MT, goodEvilBoot3_NW, goodEvilBoot3_SH, goodEvilBoot3_SHC, goodEvilBoot3_SKE, goodEvilBoot3_SOA, goodEvilBoot3_SS, goodEvilBoot3_TR, goodEvilBoot3_WH, goodEvilBoot4, goodEvilHead3, goodEvilHead4, sinsFateWeapon3, sinsFateWeapon4 } from './sins_and_fate';
import { snowFwAccL2, snowFwAccL3, snowFwAccL4, snowFwAccR2, snowFwAccR3, snowFwAccR4, snowFwArmor2, snowFwArmor3, snowFwArmor4, snowFwBoot2, snowFwBoot3, snowFwBoot4, snowFwGarment2, snowFwGarment3, snowFwGarment4 } from './snow_flower';
import { thanosBoot3, thanosBoot4, thanosHead3, thanosHead4 } from './thanos';
import { poringBalloonSlot3, poringBalloonSlot4 } from './poring_balloon';
import { sproutSlot2, sproutSlot3, sproutSlot4 } from './temporal_sprout';
import { traitShadow3, traitShadow4 } from './trait_shadow';
import { unkWatch2, unkWatch34 } from './unknown_watch';
import { corruptedPoisonArmor2, corruptedPoisonArmor3, corruptedPoisonArmor4, fieryEarthArmor2, fieryEarthArmor3, fieryEarthArmor4, flameRuneArmor2, icyStromArmor2, icyStromArmor3, icyStromArmor4, soulPurifyArmor2, soulPurifyArmor3, soulPurifyArmor4, varmundt3, varmundt4, varmundtAcc3, varmundtAcc4, varmundtHiAcc2 } from './varmundt';
import { vivatusHead3, vivatusHead4 } from './vivatus';
import { whiteKnight2, whiteKnight34 } from './white_knigh_man';
import { yorscalpAcc2, yorscalpAcc3, yorscalpAcc4, yorscalpArmor2, yorscalpArmor3, yorscalpArmor4, yorscalpBoot2, yorscalpBoot3, yorscalpBoot4, yorscalpGarment2, yorscalpGarment3, yorscalpGarment4, yorscalpHeadUpper2, yorscalpHeadUpper3, yorscalpHeadUpper4 } from './yorscalp';

enum TimeJewel {
  Str2 = 'aegis_313347',
  Str3 = 'aegis_313348',
  Agi2 = 'aegis_313349',
  Agi3 = 'aegis_313350',
  Vit2 = 'aegis_313351',
  Vit3 = 'aegis_313352',
  Int2 = 'aegis_313353',
  Int3 = 'aegis_313354',
  Dex2 = 'aegis_313355',
  Dex3 = 'aegis_313356',
  Luk2 = 'aegis_313357',
  Luk3 = 'aegis_313358',
}

const statEnums = [Str, Int, Dex, Agi, Vit, Luk];
const createBaseStat = (from: number, to: number): string[] => {
  const ls = [] as string[];

  for (const statEnum of statEnums) {
    for (let i = from; i <= to; i++) {
      ls.push(statEnum[`_${i}`]);
    }
  }

  return ls;
};
const base12 = createBaseStat(1, 2);
const base15 = createBaseStat(1, 5);
const base46 = createBaseStat(4, 6);

const BaseState = {
  _1: [Str._1, Int._1, Dex._1, Agi._1, Vit._1, Luk._1],
  _2: [Str._2, Int._2, Dex._2, Agi._2, Vit._2, Luk._2],
  _3: [Str._3, Int._3, Dex._3, Agi._3, Vit._3, Luk._3],
  _1_3: [Str._1, Str._2, Str._3, Int._1, Int._2, Int._3, Dex._1, Dex._2, Dex._3, Agi._1, Agi._2, Agi._3, Vit._1, Vit._2, Vit._3, Luk._1, Luk._2, Luk._3],
  _1_4: [
    Str._1,
    Str._2,
    Str._3,
    Str._4,
    Int._1,
    Int._2,
    Int._3,
    Int._4,
    Dex._1,
    Dex._2,
    Dex._3,
    Dex._4,
    Agi._1,
    Agi._2,
    Agi._3,
    Agi._4,
    Vit._1,
    Vit._2,
    Vit._3,
    Vit._4,
    Luk._1,
    Luk._2,
    Luk._3,
    Luk._4,
  ],
  _3_5: [Str._3, Str._4, Str._5, Int._3, Int._4, Int._5, Dex._3, Dex._4, Dex._5, Agi._3, Agi._4, Agi._5, Vit._3, Vit._4, Vit._5, Luk._3, Luk._4, Luk._5],
  _4: [Str._4, Int._4, Dex._4, Agi._4, Vit._4, Luk._4],
  _5: [Str._5, Int._5, Dex._5, Agi._5, Vit._5, Luk._5],
  _6: [Str._6, Int._6, Dex._6, Agi._6, Vit._6, Luk._6],
};
const tempOpts = {
  _1: [EA._1, FS._1, Sharp._1],
  _2: [EA._2, FS._2, Sharp._2],
  _3: [EA._3, FS._3, Sharp._3],
  _1_3: [EA._1, EA._2, EA._3, FS._1, FS._2, FS._3, Sharp._1, Sharp._2, Sharp._3],
};

const all25 = [...ea25, ...fs36, ...sh25, ...sp25, ...atkPer13, ...fatal14];
const eaFsSp15 = [...ea15, ...fs35, ...sp25, ...fatal14];

const toyFactory = [...sp25, ...fs35, ...sh13, ...matk12, AttackDelay._1, ...aspd24];
const racing3rd = [EA._1, EA._2, FS._1, FS._2, Sharp._1, Sharp._2, Fatal._1, Fatal._2, Spell._1, Spell._2, AttackDelay._1, AttackDelay._2];

const illusionArmor = ['Improve_Orb_Atk', 'Improve_Orb_Matk', 'Improve_Orb_Archer', 'Improve_Orb_Delay'];
const illusionGarment = ['Improve_Orb_Speed', 'Improve_Orb_Cast', 'Improve_Orb_Cri', 'Improve_Orb_Above'];
const illusionBoot = [
  'Improve_Orb_Fix',
  'Improve_Orb_Heal',
  'Improve_Orb_L_Vit',
  'Improve_Orb_L_INT',
  'Improve_Orb_L_DEX',
  'Improve_Orb_L_STR',
  'Improve_Orb_L_AGI',
  'Improve_Orb_L_LUK',
  'Improve_Orb_Health',
];
const illusionAcc = [EA._5, Spell._5, AttackDelay._4, Fatal._4, ...BaseState._3];
// '마법석성' = U-Mental (29545), '마법석암' = U-Mana (29546): LATAM Illusion-accessory
// magic-stone enchants (raw aegisNames — not in the kRO enchant enums).
const illusionAccR = [EA._5, Spell._5, AttackDelay._4, Fatal._4, Str._3, Agi._3, Vit._3, Luk._3, '마법석성', '마법석암'];
const illusionAccL = [EA._5, Spell._5, AttackDelay._4, Fatal._4, Int._3, Dex._3, Vit._3, Luk._3, '마법석성', '마법석암'];
const illusionShield = [
  ...illusionArmor,
  ...illusionBoot.filter((a) => a !== 'Improve_Orb_Fix'),
  ...illusionGarment.filter((a) => a !== 'Improve_Orb_Above'),
  ...illusionAcc,
];

/**
 * Automódulos — one const per column of the Automódulo table on browiki's Equipamentos
 * Automatron page. Every Automatron piece has 3 sockets and each of them offers that
 * piece's whole column; the per-module "x1/x2/x3" repeat cap the wiki prints is a rule
 * of the NPC, not of the list, and is not modelled here.
 *
 * Every column is complete, but nine of the modules carry an **empty script**: the engine
 * has no key for a heal, a regeneration or a reflected-damage effect, so they change no
 * number. They are in item.json and in these lists all the same, because a build or a
 * replay import naming one has to be able to show it in the socket the player filled —
 * dropping it would silently rewrite their gear.
 *
 *   M-HPR (310090), M-SPR (310091)        natural HP/SP regen +30%      Ac. D. / Ac. E.
 *   M-Cura (310098)                       heal effectiveness +17%       Perna, Escudo
 *   P-Vida (310113), P-Alma (310114)      HP/SP leech on hit            Ac. D. / Ac. E.
 *   P-Mental (310115), P-Mana (310116)    proc HP/SP regen when casting Ac. D. / Ac. E.
 *   P-Espelho (310178), P-Refletor (310179)  reflected-damage resist    Colete / Motor, Escudo
 *
 * P-Total (310112) was in that list until the PVP section gave the engine a defender side:
 * its "Resistência a Normais e Chefes / a todos os tamanhos / a todas as raças" is the
 * subclass_/subsize_/subrace_ namespace, and against a player attacker (Normal, Médio) the
 * first two clauses fire. It is the Automatron member of the U-Total / Orbe Lupino - Total
 * family and carries the same keys, phrase for phrase — so it is scripted, not inert.
 *
 * @see https://browiki.org/wiki/Equipamentos_Automatron
 */
const automaticJobs = [
  'Automatic_Orb46',
  'Automatic_Orb47',
  'Automatic_Orb48',
  'Automatic_Orb49',
  'Automatic_Orb50',
  'Automatic_Orb51',
  'Automatic_Orb52',
  'Automatic_Orb53',
  'Automatic_Orb54',
  'Automatic_Orb55',
  'Automatic_Orb56',
  'Automatic_Orb57',
  'Automatic_Orb58',
  'Automatic_Orb59',
  'Automatic_Orb60',
  'Automatic_Orb61',
  'Automatic_Orb62',
  'Automatic_Orb63',
  'Automatic_Orb64',
  'Automatic_Orb65',
  'Automatic_Orb66',
  'Automatic_Orb67',
  'Automatic_Orb68',
  'Automatic_Orb69',
  'Automatic_Orb70',
  'Automatic_Orb71',
  'Automatic_Orb72',
  'Automatic_Orb73',
  'Automatic_Orb74',
  'Automatic_Orb75',
  'Automatic_Orb76',
  'Automatic_Orb77',
  'Automatic_Orb78',
  'Automatic_Orb79',
  'Automatic_Orb80',
  'Automatic_Orb81',
  'Automatic_Orb82',
  'Automatic_Orb83',
  'Automatic_Orb84',
  'Automatic_Orb85',
  'Automatic_Orb86',
  'Automatic_Orb87',
  'Automatic_Orb88',
  'Automatic_Orb89',
  'Automatic_Orb90',
  'Automatic_Orb91',
  'Automatic_Orb92',
  'Automatic_Orb93',
  'Automatic_Orb94',
  'Automatic_Orb95',
  'Automatic_Orb96',
];
// B- Básico defensivos: B-DEF (Orb1, DEF +300 @+11) e B-DEFM (Orb2, DEFM +29 @+11).
// browiki Equipamentos_Automatron: aplicam em Colete/Motor/Perna (e Escudo) — x3.
const automaticBasicDef = ['Automatic_Orb1', 'Automatic_Orb2'];
const automaticArmor2 = [
  'Automatic_Orb18',
  'Automatic_Orb19',
  'Automatic_Orb20',
  'Automatic_Orb24',
  'Automatic_Orb25',
  'Automatic_Orb26',
  'Automatic_Orb27',
  'Automatic_Orb28',
  'Automatic_Orb29',
  'Automatic_Orb36',
  'Automatic_Orb97',
];
const automaticArmor = [...automaticBasicDef, ...automaticArmor2, ...automaticJobs];
const automaticGarment = [...automaticBasicDef, 'Automatic_Orb21', 'Automatic_Orb22', 'Automatic_Orb23', 'Automatic_Orb31', 'Automatic_Orb38', 'Automatic_Orb98'];
const automaticBoot = [
  ...automaticBasicDef,
  'Automatic_Orb15',
  'Automatic_Orb16',
  'Automatic_Orb17',
  'Automatic_Orb30',
  'Automatic_Orb37',
  'Automatic_Orb40',
  'Automatic_Orb41',
  'Automatic_Orb42',
  'Automatic_Orb43',
  'Automatic_Orb44',
  'Automatic_Orb45',
];
/** The Escudo column — M-Cura and P-Refletor stay out, see the note above. */
const automaticShield = [
  ...automaticBasicDef, // B-DEF x3, B-DEFM x3
  'Automatic_Orb15', // M-HPMax x2
  'Automatic_Orb16', // M-SPMax x2
  'Automatic_Orb17', // M-Cura x2
  'Automatic_Orb21', // M-Rapidez x1
  'Automatic_Orb37', // P-Robusto x1
  'Automatic_Orb38', // P-Dano x1
  'Automatic_Orb98', // P-Refletor x1
];
const automaticAcc = ['Automatic_Orb39', 'Automatic_Orb11', 'Automatic_Orb12', 'Automatic_Orb13', 'Automatic_Orb14', 'Automatic_Orb3', 'Automatic_Orb4'];
const automaticAccR = [...automaticAcc, 'Automatic_Orb5', 'Automatic_Orb6', 'Automatic_Orb9', 'Automatic_Orb32', 'Automatic_Orb34'];
const automaticAccL = [...automaticAcc, 'Automatic_Orb7', 'Automatic_Orb8', 'Automatic_Orb10', 'Automatic_Orb33', 'Automatic_Orb35'];
const auto4ThAnniGlove = [ExpertMagician._5, ...automaticAcc, 'Automatic_Orb5', 'Automatic_Orb6', 'Automatic_Orb7', 'Automatic_Orb8'];

const tempBoot_3 = ["Bear's_Power", 'Runaway_Magic', 'Speed_Of_Light', 'Muscle_Fool', 'Hawkeye', 'Lucky_Day'];
const tempBoot_4 = [...ea14, FS._7, Spell._5, AttackDelay._4];
const exoticBootLt4 = [...tempBoot_4, Vit._2, Luk._3];
const kingSmithAcc_2 = ['Gh_md_agi', 'Gh_md_str', 'Gh_md_dex', 'Gh_md_int', 'Gh_md_vit', 'Gh_md_luk'];
const kingSmithAcc_3 = [EA._4, EA._5, FS._6, FS._7, Spell._4, Spell._5, Fatal._2, Fatal._3, Sharp._3, Sharp._4, Sharp._5];
const kingSmithAcc_4 = [...BaseState._3_5];
const kingSmithMan = [EA._3, EA._4, EA._5, FS._5, FS._6, FS._7, Spell._3, Spell._4, Spell._5, Fatal._2, Fatal._3, Sharp._3, Sharp._4];

const twinCannon = [Fatal._3, AttackDelay._3, Spell._4, EA._3, ...BaseState._3];

const whiteWingSuit = [...tempOpts._1_3, ...BaseState._1_3];
// Excelion "Diagramas", by the table on browiki's Equipamento Excelion page. The four
// pieces share one pool of three slots but not the same entries: A-ESQV is armour/garment
// only, A-FOR and A-INT are the Colete's alone, and the shield and the boot take neither.
// The E-/I-/R-/C- categories are element, freeze immunity, resistance and regen — none of
// them exist as items here, so they cannot be offered.
const excelionGear = ['Reactor_A_DEF', 'Reactor_A_ATK', 'Reactor_A_MATK', 'Reactor_A_MHP', 'Reactor_A_MSP', 'Reactor_A_ASPD'];
const excelion = ['Reactor_A_AVOI', ...excelionGear];
const excelionSuit = ['Reactor_A_STR', 'Reactor_A_INT', ...excelion];

const racingShoes = [...ea45, FS._6, ...sp45, ...aspd34, ...critical34, ...BaseState._1_3];

const labHead2 = [
  Tenacity._2,
  Tenacity._3,
  Tenacity._4,
  Tenacity._5,
  Tenacity._6,
  Tenacity._7,
  Tenacity._8,
  Tenacity._9,
  Tenacity._10,
  Acute._2,
  Acute._3,
  Acute._4,
  Acute._5,
  Acute._6,
  Acute._7,
  Acute._8,
  Acute._9,
  Acute._10,
  Mettle._2,
  Mettle._3,
  Mettle._4,
  Mettle._5,
  Mettle._6,
  Mettle._7,
  Mettle._8,
  Mettle._9,
  Mettle._10,
  MasterArc._2,
  MasterArc._3,
  MasterArc._4,
  MasterArc._5,
  MasterArc._6,
  MasterArc._7,
  MasterArc._8,
  MasterArc._9,
  MasterArc._10,
  MagicEess._2,
  MagicEess._3,
  MagicEess._4,
  MagicEess._5,
  MagicEess._6,
  MagicEess._7,
  MagicEess._8,
  MagicEess._9,
  MagicEess._10,
  Adamatine._2,
  Adamatine._3,
  Adamatine._4,
  Adamatine._5,
  Adamatine._6,
  Adamatine._7,
  Adamatine._8,
  Adamatine._9,
  Adamatine._10,
];
const bioHead2 = [...labHead2];

const tempHead4 = [...base15];
const tempHead3 = [
  'Time_Jewely_Str_1',
  'Time_Jewely_Str_2',
  'Time_Jewely_Str_3',
  'Time_Jewely_Agi_1',
  'Time_Jewely_Agi_2',
  'Time_Jewely_Agi_3',
  'Time_Jewely_Luk_1',
  'Time_Jewely_Luk_2',
  'Time_Jewely_Luk_3',
  'Time_Jewely_Vit_1',
  'Time_Jewely_Vit_2',
  'Time_Jewely_Vit_3',
  'Time_Jewely_Int_1',
  'Time_Jewely_Int_2',
  'Time_Jewely_Int_3',
  'Time_Jewely_Dex_1',
  'Time_Jewely_Dex_2',
  'Time_Jewely_Dex_3',
  ...tempHead4,
];
const tempHead2 = [...bioHead2, ...ea14, ...sh14, ...sp14, ...aspd14];

const sarahAcc4 = [...critical23, ...fatal12, ...ea12, ...matk12, ...aspd12, ...delay12, ...perfectD12];
const sarahAcc3 = [...critical24, ...fatal13, ...ea13, ...matk13, ...aspd13, ...delay13, ...perfectD13];

const edda4 = [EA._1, EA._2, EA._3, FS._4, FS._5, FS._6, Sharp._1, Sharp._2, Sharp._3, Spell._1, Spell._2, Spell._3, Fatal._1, Fatal._2, Fatal._3];
const edda3 = [
  'Seyren_Memory',
  'Harword_Memory',
  'Eremes_Memory',
  'Katrinn_Memory',
  'Magaleta_Memory',
  'Shecil_Memory',
  'Randel_Memory',
  'Flamel_Memory',
  'Gertie_Memory',
  'Celia_Memory',
  'Chen_Memory',
  'Tren_Memory',
  'Alpho_Memory',
];

const allRunes = [
  RuneStr._1,
  RuneStr._2,
  RuneStr._3,
  RuneDex._1,
  RuneDex._2,
  RuneDex._3,
  RuneInt._1,
  RuneInt._2,
  RuneInt._3,
  RuneLuk._1,
  RuneLuk._2,
  RuneLuk._3,
  RuneAgi._1,
  RuneAgi._2,
  RuneAgi._3,
  RuneVit._1,
  RuneVit._2,
  RuneVit._3,
];

const specials = ['S_Str', 'S_Agi', 'S_Vital', 'S_Int', 'S_Dex', 'S_Luck'];

const bpBioLab43 = [...ea15, ...ef15, ...em15];
const bpBioLab2 = [
  "[Event]_Seyren's Memory",
  "[Event]_Howard's Memory",
  "[Event]_Eremes's Memory",
  "[Event]_Kathryne's Memory",
  "[Event]_Margaretha's Memory",
  "[Event]_Cecil's Memory",
  "[Event]_Randel's Memory",
  "[Event]_Flamel's Memory",
  "[Event]_Gertie's Memory",
  "[Event]_Celia's Memory",
  "[Event]_Chen's Memory",
  "[Event]_Trentini's Memory",
  "[Event]_Alphoccio's Memory",
];

const malangdo = [
  EA._2,
  EA._3,
  EA._4,
  EA._5,
  EA._6,
  Spell._2,
  Spell._3,
  Spell._4,
  Spell._5,
  Spell._6,
  FS._4,
  FS._5,
  FS._6,
  FS._7,
  FS._8,
  Sharp._2,
  Sharp._3,
  Sharp._4,
  Sharp._5,
  ASPD._1,
  MatkPercent._1,
  MatkPercent._2,
  ...createBaseStat(2, 6),
];

const goldenSet = [...all25];

interface EntTable {
  name: string;
  enchants: [null | string[], string[], string[], string[]];
}

const soutanes = ['Cassock_Str', 'Cassock_Agi', 'Cassock_Vit', 'Cassock_Dex', 'Cassock_Int', 'Cassock_Luk'];
// https://browiki.org/wiki/Hugel#Equipamentos_Angelicais
// Slots 3/4 always use the base pool. Slot 2 combines the +0–8 and +9 pools
// (normal/MiauMiau), like other refine-dependent enchants in this static table.
const soutaneBase = [
  ...cri510, ...mhp35, MSP._100, MSP._150, ...createBaseStat(6, 8),
  'Evasion6', 'Evasion10', 'Def12', 'Def18', 'Mdef2', 'Mdef4',
];
const soutaneGarmentBoot2 = [...soutaneBase, 'Def20', 'Mdef6', 'Mdef8'];
const soutaneArmor2 = [
  ...soutaneBase, 'Def21', 'Mdef10', ...soutanes,
  FS._5, FS._6, Spell._4, Spell._5, EA._4, EA._5, Sharp._4, Sharp._5,
  AttackDelay._3, AttackDelay._4,
];

const sinful4 = [
  'Tha_Wrath_1',
  'Tha_Wrath_2',
  'Tha_Wrath_3',
  'Tha_Wrath_4',
  'Tha_Wrath_5',
  'Tha_Majesty_1',
  'Tha_Majesty_2',
  'Tha_Majesty_3',
  'Tha_Majesty_4',
  'Tha_Majesty_5',
];
const sinful3 = [
  'Tha_Anger_1',
  'Tha_Anger_2',
  'Tha_Anger_3',
  'Tha_Anger_4',
  'Tha_Anger_5',
  'Tha_Horror_1',
  'Tha_Horror_2',
  'Tha_Horror_3',
  'Tha_Horror_4',
  'Tha_Horror_5',
  'Tha_Resent_1',
  'Tha_Resent_2',
  'Tha_Resent_3',
  'Tha_Resent_4',
  'Tha_Resent_5',
  'Tha_Regret_1',
  'Tha_Regret_2',
  'Tha_Regret_3',
  'Tha_Regret_4',
  'Tha_Regret_5',
];

const brilliant4 = [
  'Tha_demigod_1',
  'Tha_demigod_2',
  'Tha_demigod_3',
  'Tha_demigod_4',
  'Tha_demigod_5',
  'Tha_Antigod_1',
  'Tha_Antigod_2',
  'Tha_Antigod_3',
  'Tha_Antigod_4',
  'Tha_Antigod_5',
];
const brilliant3 = [
  'Tha_Empatize_1',
  'Tha_Empatize_2',
  'Tha_Empatize_3',
  'Tha_Empatize_4',
  'Tha_Empatize_5',
  'Tha_Happy_1',
  'Tha_Happy_2',
  'Tha_Happy_3',
  'Tha_Happy_4',
  'Tha_Happy_5',
  'Tha_Comfort_1',
  'Tha_Comfort_2',
  'Tha_Comfort_3',
  'Tha_Comfort_4',
  'Tha_Comfort_5',
  'Tha_Console_1',
  'Tha_Console_2',
  'Tha_Console_3',
  'Tha_Console_4',
  'Tha_Console_5',
];

const infityEnt4 = [...ea13, ...delay13, ...aspd13, ...critical24, ...fatal13, ...matkP35, ...BaseState._3];
// Asas de Arcanjo: one enchant in slot 4, including healing and resistance stones.
// https://browiki.org/wiki/Malangdo#Encantamento_Arcanjo
const wing4 = [...ea23, ...fs23, ...sp23, ...sh23, ...matk12, ...specials, ...base12,
  'Heal_Amount3', 'Heal_Amount4', 'Heal_Amount5', '투명한보석', '진홍색보석'];
const subject = [...BaseState._5, ...fs68, ...ea35, ...sp46, ...delay13];

const year2nd = [...allRunes, ...fs45, ...sp34, ...ea12, ...critical23, ...mhp34, ...shedding12, ...BaseState._1_3];

const timeJewel2_4 = [...sp45, ...ea45, ...fs67, ...sh45, ...fatal23];
const timeJewel2_3 = [TimeJewel.Str2, TimeJewel.Agi2, TimeJewel.Vit2, TimeJewel.Int2, TimeJewel.Dex2, TimeJewel.Luk2];
const timeJewel3_3 = [TimeJewel.Str3, TimeJewel.Agi3, TimeJewel.Vit3, TimeJewel.Int3, TimeJewel.Dex3, TimeJewel.Luk3];

const bp5Armor = [
  'Battle_Pass_ATK',
  'Battle_Pass_MATK',
  'Battle_Pass_Magical Force',
  'Battle_Pass_Attacker Force',
  'Battle_Pass_Range Force',
  'Battle_Pass_Critical Force',
  'Battle_Pass_Global Cooldown',
];
const bp5Mask = ['Essence_of_Sin_Fate_Lv1', 'Essence_of_Sin_Fate_Lv2', 'Essence_of_Sin_Fate_Lv3'];

/**
 * Encantos dos Capacetes (Passe de Batalha) — Capacete Fortificado / Decadente / Descartado.
 * Same pool on slots 2, 3 and 4 ("Ordem do encanto: Slot 4 > Slot 3 > Slot 2").
 *
 * The same seven `Battle_Pass_*` ids as bp5Armor, plus P-Mágico (Automatic_Orb24) — LATAM
 * reuses the ids under different pt-BR names, so read them as: Encanto de Ataque, Encanto de
 * Poder, P-Mágico, Encanto de Conjuração, Encanto de Talento, Encanto Decadente, Encanto
 * Fortificado, Encanto de Sucata. The wiki's "Limite" column (x2/x1) caps copies per
 * capacete; nothing here models a cross-slot limit.
 */
const capaceteBP = [
  'Battle_Pass_ATK',
  'Battle_Pass_MATK',
  'Automatic_Orb24',
  'Battle_Pass_Magical Force',
  'Battle_Pass_Attacker Force',
  'Battle_Pass_Range Force',
  'Battle_Pass_Critical Force',
  'Battle_Pass_Global Cooldown',
];

const nebular2 = [
  'Star_Cluster_Of_Pow1',
  'Star_Cluster_Of_Pow2',
  'Star_Cluster_Of_Pow3',
  'Star_Cluster_Of_Sta1',
  'Star_Cluster_Of_Sta2',
  'Star_Cluster_Of_Sta3',
  'Star_Cluster_Of_Con1',
  'Star_Cluster_Of_Con2',
  'Star_Cluster_Of_Con3',
  'Star_Cluster_Of_Crt1',
  'Star_Cluster_Of_Crt2',
  'Star_Cluster_Of_Crt3',
  'Star_Cluster_Of_Spl1',
  'Star_Cluster_Of_Spl2',
  'Star_Cluster_Of_Spl3',
  'Star_Cluster_Of_Wis1',
  'Star_Cluster_Of_Wis2',
  'Star_Cluster_Of_Wis3',
];
const nebular3 = [
  'Nebula_Of_FS1',
  'Nebula_Of_FS2',
  'Nebula_Of_FS3',
  'Nebula_Of_EA1',
  'Nebula_Of_EA2',
  'Nebula_Of_EA3',
  'Nebula_Of_SH1',
  'Nebula_Of_SH2',
  'Nebula_Of_SH3',
  'Nebula_Of_SP1',
  'Nebula_Of_SP2',
  'Nebula_Of_SP3',
  'Nebula_Of_HP1',
  'Nebula_Of_HP2',
  'Nebula_Of_HP3',
];
const nebular4 = [...str(3, 5), ...int(3, 5), ...dex(2, 4), ...agi(3, 5), ...vit(3, 5)];

const moraAtkType1 = [...atkPer13, ...fs13, ...str(1, 3)];
const moraAtkType2 = [...atkPer23, ...fs24, ...str(2, 4)];
const moraAtkType3 = [AtkPercent._3, ...fs36, ...str(3, 5)];

const moraSpellAbility1 = [MatkPercent._1, ...sp23, ...dex(2, 3), ...int(2, 3)];
const moraSpellAbility2 = [...matk12, ...sp34, ...dex(3, 4), ...int(3, 4)];
const moraSpellAbility3 = [...matk13, Spell._4, ...dex(3, 5), ...int(3, 5)];

const maceOfJudge = [...dex(1, 2), ...str(1, 4), ...vit(1, 2), AtkPercent._3];
const robeOfJudge = [...dex(1, 4), ...int(1, 4), Str._4, Vit._1, AtkPercent._2, MatkPercent._2, Cri._5];
const shawnOfJudge = [...dex(1, 4), ...int(1, 2), Vit._1];
const shoeOfJudge = [...dex(2, 4), ...int(1, 2), AtkPercent._2];

const heroRing4 = [Spell._3, Spell._5, EA._3, EA._5, AttackDelay._2, AttackDelay._4, ExpertFighter._3, ExpertFighter._5, ExpertMagician._3, ExpertMagician._5];

export const EnchantTable: EntTable[] = [
  { name: 'LittleGarden_LT', enchants: [null, null, null, littleGardenSlot4] },
  { name: 'Explorer_Engine_LT', enchants: [null, explorerEngineEnchants, explorerEngineEnchants, explorerEngineEnchants] },
  { name: 'Lush_Rose', enchants: [null, null, BaseState._1_3, toyFactory] },
  { name: 'Celines_Ribbon', enchants: [null, null, BaseState._1_3, toyFactory] },

  { name: 'Mace_Of_Judgement', enchants: [null, null, maceOfJudge, maceOfJudge] },
  {
    name: 'Mace_Of_Judgement2',
    enchants: [null, [...moraAtkType3, ...moraSpellAbility3], [...moraAtkType2, ...moraSpellAbility2], [...moraAtkType1, ...moraSpellAbility1]],
  },
  { name: 'Robe_Of_Judgement', enchants: [null, robeOfJudge, robeOfJudge, robeOfJudge] },
  { name: 'Shawl_Of_Judgement', enchants: [null, shawnOfJudge, shawnOfJudge, shawnOfJudge] },
  { name: 'Shoes_Of_Judgement', enchants: [null, shoeOfJudge, shoeOfJudge, shoeOfJudge] },

  { name: 'Dark_Rose', enchants: [null, null, malangdo, malangdo] },
  { name: 'Just_Finish', enchants: [null, null, malangdo, malangdo] },
  { name: 'Holy_Stick', enchants: [null, null, malangdo, malangdo] },
  { name: 'Katar_170', enchants: [null, null, malangdo, malangdo] },
  { name: 'Krishna', enchants: [null, null, malangdo, malangdo] },
  { name: 'Two_Hand_Spear_170', enchants: [null, null, malangdo, malangdo] },
  { name: 'Staff_170', enchants: [null, null, malangdo, malangdo] },
  { name: 'Cakram', enchants: [null, null, malangdo, malangdo] },
  { name: 'House_Auger', enchants: [null, null, malangdo, malangdo] },
  { name: 'Thorn_Staff_', enchants: [null, null, malangdo, malangdo] },
  { name: 'Kronos', enchants: [null, null, malangdo, malangdo] },
  { name: 'Balistar_IL', enchants: [null, null, malangdo, malangdo] },
  { name: 'Burning_Rose', enchants: [null, null, malangdo, malangdo] },
  { name: 'Twin_Edge_B', enchants: [null, null, null, malangdo] },
  { name: 'Twin_Edge_R', enchants: [null, null, null, malangdo] },
  { name: 'Death_Guidance', enchants: [null, null, malangdo, malangdo] },
  { name: 'Destruction_Rod', enchants: [null, null, malangdo, malangdo] },
  { name: 'Poison_Forged_Spear', enchants: [null, null, null, malangdo] },
  { name: 'Revenger', enchants: [null, null, malangdo, malangdo] },
  { name: 'Bazerald', enchants: [null, null, malangdo, malangdo] },
  { name: 'Sealed_Evil_Sword', enchants: [null, null, malangdo, malangdo] },
  { name: 'Black_Wing', enchants: [null, null, malangdo, malangdo] },
  { name: 'Ex_Y_Model_Foxtail', enchants: [null, malangdo, malangdo, malangdo] },
  { name: 'Magical_Y_Foxtail', enchants: [null, malangdo, malangdo, malangdo] },
  { name: 'Gungnir_', enchants: [null, null, malangdo, malangdo] },

  { name: 'Golden_Ninja_Suit', enchants: [null, goldenSet, goldenSet, goldenSet] },
  { name: 'Golden_Scarf', enchants: [null, goldenSet, goldenSet, goldenSet] },

  { name: 'CUSTOM_Racing_Shoes', enchants: [null, null, racingShoes, racingShoes] },

  // Brotos Temporais — see temporal_sprout.ts for why the wiki's single row covers all
  // six sprouts, and why the three lists run tier by tier.
  { name: 'Tree_Of_Sprout_STR', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },
  { name: 'Tree_Of_Sprout_DEX', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },
  { name: 'Tree_Of_Sprout_AGI', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },
  { name: 'Tree_Of_Sprout_LUK', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },
  { name: 'Tree_Of_Sprout_VIT', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },
  { name: 'Tree_Of_Sprout_INT', enchants: [null, sproutSlot2, sproutSlot3, sproutSlot4] },

  // Balões Poring — one table for all eleven. Slot 3 rolls only the "Mestre" EXP stones,
  // which the calculator cannot price but still offers. See poring_balloon.ts.
  { name: 'Poring_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Marin_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Drops_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'SantaPoring_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Poporing_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Metaling_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Deviling_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Angeling_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Ghostring_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  { name: 'Archangeling_Balloon', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },
  // 19095, the one browiki's table does not name — see poring_balloon.ts.
  { name: 'Happy_Balloon_K', enchants: [null, null, poringBalloonSlot3, poringBalloonSlot4] },

  { name: 'Tree_Of_Sprout_JP', enchants: [null, BaseState._1_3, BaseState._1_3, infityEnt4] },
  { name: 'Tengu_Scroll', enchants: [null, BaseState._1_3, BaseState._1_3, infityEnt4] },
  { name: 'Royalguard_Necklace', enchants: [null, BaseState._1_3, BaseState._1_3, infityEnt4] },
  { name: 'Protect_cloth', enchants: [null, BaseState._1_3, BaseState._1_3, infityEnt4] },
  { name: 'Heart_Card_In_Mouth', enchants: [null, BaseState._1_3, BaseState._1_3, infityEnt4] },

  { name: 'Fallen Angel Wing [1]', enchants: [null, eaFsSp15, eaFsSp15, eaFsSp15] },

  { name: 'Excelion_Suit', enchants: [null, excelionSuit, excelionSuit, excelionSuit] },
  { name: 'Excelion_Wing', enchants: [null, excelion, excelion, excelion] },
  { name: 'Excelion_Shield', enchants: [null, excelionGear, excelionGear, excelionGear] },
  { name: 'Excelion_Boots', enchants: [null, excelionGear, excelionGear, excelionGear] },

  { name: 'Racing_C_Mecha', enchants: [null, ['Racing_E_Mecha1', 'Racing_E_Mecha2', 'Racing_E_Mecha3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Gene', enchants: [null, ['Racing_E_Gene1', 'Racing_E_Gene2', 'Racing_E_Gene3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Cross', enchants: [null, ['Racing_E_Cross1', 'Racing_E_Cross2', 'Racing_E_Cross3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Chaser', enchants: [null, ['Racing_E_Chaser1', 'Racing_E_Chaser2', 'Racing_E_Chaser3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Warlock', enchants: [null, ['Racing_E_Warlock1', 'Racing_E_Warlock2', 'Racing_E_Warlock3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Sorcer', enchants: [null, ['Racing_E_Sorcer1', 'Racing_E_Sorcer2', 'Racing_E_Sorcer3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Rune', enchants: [null, ['Racing_E_Rune1', 'Racing_E_Rune2', 'Racing_E_Rune3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Royal', enchants: [null, ['Racing_E_Royal1', 'Racing_E_Royal2', 'Racing_E_Royal3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Bishop', enchants: [null, ['Racing_E_Bishop1', 'Racing_E_Bishop2', 'Racing_E_Bishop3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Sura', enchants: [null, ['Racing_E_Sura1', 'Racing_E_Sura2', 'Racing_E_Sura3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Ranger', enchants: [null, ['Racing_E_Ranger1', 'Racing_E_Ranger2', 'Racing_E_Ranger3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Mins', enchants: [null, ['Racing_E_Wand_Min1', 'Racing_E_Wand_Min2', 'Racing_E_Wand_Min3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Wander', enchants: [null, ['Racing_E_Wand_Min1', 'Racing_E_Wand_Min2', 'Racing_E_Wand_Min3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Gunner', enchants: [null, ['Racing_E_Gunner1', 'Racing_E_Gunner2', 'Racing_E_Gunner3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Ninja', enchants: [null, ['Racing_E_Ninja1', 'Racing_E_Ninja2', 'Racing_E_Ninja3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Super', enchants: [null, ['Racing_E_Super1', 'Racing_E_Super2', 'Racing_E_Super3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Doram', enchants: [null, ['Racing_E_Doram1', 'Racing_E_Doram2', 'Racing_E_Doram3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Star', enchants: [null, ['Racing_E_Star1', 'Racing_E_Star2', 'Racing_E_Star3', ...racing3rd], BaseState._1_4, BaseState._1_3] },
  { name: 'Racing_C_Soul', enchants: [null, ['Racing_E_Soul1', 'Racing_E_Soul2', 'Racing_E_Soul3', ...racing3rd], BaseState._1_4, BaseState._1_3] },

  { name: 'Subject_CapeRange_TH', enchants: [null, subject, subject, subject] },
  { name: 'Subject_CapeMagic_TH', enchants: [null, subject, subject, subject] },
  { name: 'Subject_CapeMelee_TH', enchants: [null, subject, subject, subject] },

  { name: 'Illusion_Armor_A', enchants: [null, illusionArmor, illusionArmor, illusionArmor] },
  { name: 'Illusion_Armor_B', enchants: [null, illusionArmor, illusionArmor, illusionArmor] },
  { name: 'Illusion_Engine_A', enchants: [null, illusionGarment, illusionGarment, illusionGarment] },
  { name: 'Illusion_Engine_B', enchants: [null, illusionGarment, illusionGarment, illusionGarment] },
  { name: 'Illusion_Leg_A', enchants: [null, illusionBoot, illusionBoot, illusionBoot] },
  { name: 'Illusion_Leg_B', enchants: [null, illusionBoot, illusionBoot, illusionBoot] },
  { name: 'Illusion_B_R', enchants: [null, illusionAccR, illusionAccR, illusionAccR] },
  { name: 'Illusion_BC_R', enchants: [null, illusionAccR, illusionAccR, illusionAccR] },
  { name: 'Illusion_B_L', enchants: [null, illusionAccL, illusionAccL, illusionAccL] },
  { name: 'Illusion_BC_L', enchants: [null, illusionAccL, illusionAccL, illusionAccL] },
  { name: 'Illusion_Shield_A', enchants: [null, illusionShield, illusionShield, illusionShield] },
  { name: 'Illusion_Shield_B', enchants: [null, illusionShield, illusionShield, illusionShield] },

  // [Apoio]/bound "E_" Illusion pieces: same enchant pools as their base
  // counterparts. Required so replay/preset imports render their socket-enchants
  // — getEnchants() matches by exact aegisName, and the E_ prefix has no base entry.
  { name: 'E_Illusion_Armor_A', enchants: [null, illusionArmor, illusionArmor, illusionArmor] },
  { name: 'E_Illusion_Engine_B', enchants: [null, illusionGarment, illusionGarment, illusionGarment] },
  { name: 'E_Illusion_Leg_A', enchants: [null, illusionBoot, illusionBoot, illusionBoot] },
  { name: 'E_Illusion_B_R', enchants: [null, illusionAccR, illusionAccR, illusionAccR] },
  { name: 'E_Illusion_B_L', enchants: [null, illusionAccL, illusionAccL, illusionAccL] },

  { name: '[Upgrade] Illusion Ring [1]', enchants: [null, illusionAcc, illusionAcc, illusionAcc] },
  { name: 'Secret Illusion Ring [1]', enchants: [null, ['Improve_Orb_L_Varmundt', ...illusionAcc], illusionAcc, illusionAcc] },

  { name: 'Auto_Armor_A', enchants: [null, automaticArmor, automaticArmor, automaticArmor] },
  { name: 'Auto_Armor_B', enchants: [null, automaticArmor, automaticArmor, automaticArmor] },
  { name: 'Auto_Engine_A', enchants: [null, automaticGarment, automaticGarment, automaticGarment] },
  { name: 'Auto_Engine_B', enchants: [null, automaticGarment, automaticGarment, automaticGarment] },
  { name: 'Auto_Leg_A', enchants: [null, automaticBoot, automaticBoot, automaticBoot] },
  { name: 'Auto_Leg_B', enchants: [null, automaticBoot, automaticBoot, automaticBoot] },
  { name: 'Auto_Shield_A_LT', enchants: [null, automaticShield, automaticShield, automaticShield] },
  { name: 'Auto_Shield_B_LT', enchants: [null, automaticShield, automaticShield, automaticShield] },
  { name: 'Auto_B_R', enchants: [null, automaticAccR, automaticAccR, automaticAccR] },
  { name: 'Auto_B_L', enchants: [null, automaticAccL, automaticAccL, automaticAccL] },
  { name: 'Auto_BC_R', enchants: [null, automaticAccR, automaticAccR, automaticAccR] },
  { name: 'Auto_BC_L', enchants: [null, automaticAccL, automaticAccL, automaticAccL] },
  { name: 'aegisName_490565', enchants: [null, auto4ThAnniGlove, auto4ThAnniGlove, auto4ThAnniGlove] },

  { name: 'Temporal_Cape_TW_LT', enchants: [null, whiteKnight2, whiteKnight34, whiteKnight34] },
  { name: 'Temporal_Boots_LT_TW', enchants: [null, null, tempBoot_3, exoticBootLt4] },

  { name: 'Temporal_Boots_TW', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Str_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Int_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Agi_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Vit_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Dex_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Luk_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Str_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Int_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Agi_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Vit_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Dex_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Temporal_Luk_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },

  { name: 'Modify_Str_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Int_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Agi_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Vit_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Dex_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Luk_Boots', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Str_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Int_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Agi_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Vit_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Dex_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },
  { name: 'Modify_Luk_Boots_', enchants: [null, null, tempBoot_3, tempBoot_4] },

  { name: 'Schmidt_Manteau', enchants: [null, kingSmithMan, kingSmithMan, kingSmithMan] },
  { name: 'Schmidt_Insignia_Str', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Schmidt_Insignia_Int', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Schmidt_Insignia_Agi', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Schmidt_Insignia_Vit', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Schmidt_Insignia_Dex', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Schmidt_Insignia_Luk', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'TimeOverloadRing_TW', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },
  { name: 'Temporal_Ring', enchants: [null, kingSmithAcc_2, kingSmithAcc_3, kingSmithAcc_4] },

  { name: 'Twin Cannon', enchants: [null, twinCannon, twinCannon, twinCannon] },

  { name: 'Temporal_Ring_TW', enchants: [null, null, null, [...ea410, ...fs410, ...sp46, ...base46]] },
  { name: 'Temporal_Ring_LT_TH', enchants: [null, null, null, [...ea410, ...fs410, ...sp46, ...base46]] },

  { name: 'Earring_Of_Sarah_L', enchants: [null, null, sarahAcc3, sarahAcc4] },
  { name: 'Earring_Of_Sarah_R', enchants: [null, null, sarahAcc3, sarahAcc4] },

  { name: 'White_Wing_Suits', enchants: [null, whiteWingSuit, whiteWingSuit, whiteWingSuit] },
  { name: 'White_Wing_Manteau', enchants: [null, [...atkPer13, ...fs13], [...atkPer13, ...fs13], [...atkPer13, ...fs13]] },
  { name: 'White_Wing_Brooch', enchants: [null, null, null, BaseState._1] },

  { name: 'Vigilante_Bedge', enchants: [null, null, BaseState._1, BaseState._1] },
  { name: 'Vigilante_Suits', enchants: [null, BaseState._1, BaseState._1, BaseState._1] },

  { name: 'Old_Rune_Circlet', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Mitra', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Driver_Band_R', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Driver_Band_Y', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Shadow_Handicraft', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Minstrel_Song_Hat', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Midas_Whisper', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Magic_Stone_Hat', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Blazing_Soul', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Wind_Whisper', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Dying_Swan', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Circlet_Of_Bone', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Protect_Of_Crown', enchants: [null, labHead2, base15, base15] },
  { name: 'Old_Camo_RabbitHood', enchants: [null, labHead2, base15, base15] },

  // { name: 'BioWeapon_Helm_RK', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_LG', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_WL', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_SO', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_NC', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_GN', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_RA', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_WM', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_AB', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_SR', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_SC', enchants: [null, bioHead2, base15, base15] },
  // { name: 'BioWeapon_Helm_GC', enchants: [null, bioHead2, base15, base15] },

  { name: 'S_Circlet_Of_Time_RK', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_LG', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_NC', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_GN', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_GC', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SU', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SC', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_AB', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SR', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_WL', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SO', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_RA', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_WM', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SJ', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SP', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_RL', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_OB', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_KG', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_NV', enchants: [null, tempHead2, tempHead3, tempHead4] },
  { name: 'S_Circlet_Of_Time_SU', enchants: [null, tempHead2, tempHead3, tempHead4] },

  { name: 'Sharp_Star_Bow', enchants: [null, null, edda3, edda4] },
  { name: 'Aiming_Bow', enchants: [null, null, edda3, edda4] },
  { name: 'Falken_Shooter', enchants: [null, null, edda3, edda4] },
  { name: 'Wind_Gale', enchants: [null, null, edda3, edda4] },
  { name: 'Farthezan', enchants: [null, null, edda3, edda4] },
  { name: 'Estal', enchants: [null, null, edda3, edda4] },
  { name: 'Heart_Whip', enchants: [null, null, edda3, edda4] },
  { name: 'Reaper_Cross', enchants: [null, null, edda3, edda4] },
  { name: 'Jack_The_Knife', enchants: [null, null, edda3, edda4] },
  { name: 'Antique_Cello', enchants: [null, null, edda3, edda4] },
  { name: 'Fortrage', enchants: [null, null, edda3, edda4] },
  { name: 'Harve', enchants: [null, null, edda3, edda4] },
  { name: 'Argen_Blanco', enchants: [null, null, edda3, edda4] },
  { name: 'Judgement_Slasher', enchants: [null, null, edda3, edda4] },
  { name: 'Rapid_Fire_C_Bow', enchants: [null, null, edda3, edda4] },
  { name: 'Volar', enchants: [null, null, edda3, edda4] },
  { name: 'Vernan', enchants: [null, null, edda3, edda4] },
  { name: 'Crimson_Rose_Stick', enchants: [null, null, edda3, edda4] },
  { name: 'Psychic_Spear_Rod', enchants: [null, null, edda3, edda4] },
  { name: 'Dust_Grave', enchants: [null, null, edda3, edda4] },
  { name: 'Ponitendtia', enchants: [null, null, edda3, edda4] },
  { name: 'Scarlet_Ribbon', enchants: [null, null, edda3, edda4] },
  { name: 'Agudo_Filo', enchants: [null, null, edda3, edda4] },
  { name: 'Maxi_Spanner', enchants: [null, null, edda3, edda4] },
  { name: 'Engine_Pilebuncker', enchants: [null, null, edda3, edda4] },
  { name: 'Coolant_Injection', enchants: [null, null, edda3, edda4] },
  { name: 'Gene_Rod', enchants: [null, null, edda3, edda4] },
  { name: 'Lucis_Flail', enchants: [null, null, edda3, edda4] },
  { name: 'Bright_Mace', enchants: [null, null, edda3, edda4] },
  { name: 'Adorare_Staff', enchants: [null, null, edda3, edda4] },
  { name: 'Gravitation_Staff', enchants: [null, null, edda3, edda4] },
  { name: 'Staff_Of_Miracle', enchants: [null, null, edda3, edda4] },
  { name: 'Golden_Wrench', enchants: [null, null, edda3, edda4] },
  { name: 'Boltigin', enchants: [null, null, edda3, edda4] },
  { name: 'Combo_Fist', enchants: [null, null, edda3, edda4] },
  { name: 'Asura_Bandage', enchants: [null, null, edda3, edda4] },
  { name: 'Platinum_Dagger', enchants: [null, null, edda3, edda4] },
  { name: 'Black_Circle', enchants: [null, null, edda3, edda4] },

  { name: 'Headband_Of_Power_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Apple_Of_Archer_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Fancy_Flower_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Goibne_Helmet_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Herald_Of_GOD_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Morpheus_Hood_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Boots_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Shoes_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Muffler_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: 'Siver_Guard_IL', enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: "Sprint_Mail_IL", enchants: [null, null, illusionDunArmor, illusionDunArmor] },
  { name: "Sprint_Shoes_IL", enchants: [null, null, illusionDunArmor, illusionDunArmor] },

  { name: "Sprint_Glove_IL", enchants: [null, null, illusionDunAcc, illusionDunAcc] },
  { name: "Sprint_Ring_IL", enchants: [null, null, illusionDunAcc, illusionDunAcc] },

  { name: 'Robe_Of_Flattery', enchants: [null, null, allRunes, allRunes] },
  { name: 'Robe_Of_Vituperation', enchants: [null, null, allRunes, allRunes] },

  { name: 'FaceWorm_Skin_', enchants: [null, specials, BaseState._3_5, BaseState._3_5] },
  { name: 'Archangel_Wing', enchants: [null, null, null, wing4] },

  { name: 'Sin_Necklace_R', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_R', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Necklace_E', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_E', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Necklace_T', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_T', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Necklace_A', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_A', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Necklace_S', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_S', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Necklace_O', enchants: [null, null, sinful3, sinful4] },
  { name: 'Sin_Ring_O', enchants: [null, null, sinful3, sinful4] },

  { name: 'Cassock_Manteau', enchants: [null, soutaneGarmentBoot2, soutaneBase, soutaneBase] },
  { name: 'Cassock_Boots', enchants: [null, soutaneGarmentBoot2, soutaneBase, soutaneBase] },
  { name: 'CassockA_STR', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },
  { name: 'CassockA_AGI', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },
  { name: 'CassockA_VIT', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },
  { name: 'CassockA_DEX', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },
  { name: 'CassockA_INT', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },
  { name: 'CassockA_LUK', enchants: [null, soutaneArmor2, soutaneBase, soutaneBase] },

  { name: 'Shine_Ring_R', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_R', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Ring_A', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_A', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Ring_E', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_E', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Ring_Z', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_Z', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Ring_S', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_S', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Ring_AQ', enchants: [null, null, brilliant3, brilliant4] },
  { name: 'Shine_Necklace_AQ', enchants: [null, null, brilliant3, brilliant4] },

  { name: 'Apollo_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Jupiter_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Mars_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Ceres_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Vinus_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Vulcan_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Neptune_Armor_TH', enchants: [null, year2nd, year2nd, year2nd] },
  { name: 'Neptune_ArmorDoram_TH', enchants: [null, year2nd, year2nd, year2nd] },

  { name: 'Biolab_Cape(Melee)', enchants: [null, bpBioLab2, bpBioLab43, bpBioLab43] },
  { name: 'Biolab_Cape(Magic)', enchants: [null, bpBioLab2, bpBioLab43, bpBioLab43] },
  { name: 'Biolab_Cape(Range)', enchants: [null, bpBioLab2, bpBioLab43, bpBioLab43] },

  { name: 'aegis_490583', enchants: [null, null, timeJewel2_3, timeJewel2_4] },
  { name: 'aegis_490584', enchants: [null, null, timeJewel3_3, timeJewel2_4] },

  { name: 'Abyss_Dress', enchants: [null, bp5Armor, bp5Armor, bp5Armor] },
  { name: 'Neutral_Dress', enchants: [null, bp5Armor, bp5Armor, bp5Armor] },
  { name: 'Gabriel_Dress', enchants: [null, bp5Armor, bp5Armor, bp5Armor] },
  { name: 'Ice_Flame_Dress', enchants: [null, bp5Armor, bp5Armor, bp5Armor] },
  { name: 'Red_Serpent_Dress', enchants: [null, bp5Armor, bp5Armor, bp5Armor] },
  { name: 'Mask_of_Sin_Fate', enchants: [null, null, null, bp5Mask] },

  // Máscara de Pesar (436031): one Anti-Horário enchant in slot 4.
  { name: 'THA_DOLOR_MASK', enchants: [null, null, null, [SkillDelay._1, SkillDelay._2, SkillDelay._3]] },

  // Capacete Decadente / Fortificado / Descartado (401433-401435).
  { name: 'RTC3등투구', enchants: [null, capaceteBP, capaceteBP, capaceteBP] },
  { name: 'RTC준우승자투구', enchants: [null, capaceteBP, capaceteBP, capaceteBP] },
  { name: 'RTC우승자투구', enchants: [null, capaceteBP, capaceteBP, capaceteBP] },

  { name: "Poenetentia_D_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_P_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_V_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_H_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_S_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_B_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_M_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_A_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },
  { name: "Poenetentia_I_Crown_TH", enchants: [null, bp7_2, bp7_4, bp7_4] },

  { name: 'Star_Armor_Of_Pow', enchants: [null, nebular2, nebular3, nebular4] },
  { name: 'Star_Armor_Of_Sta', enchants: [null, nebular2, nebular3, nebular4] },
  { name: 'Star_Suit_Of_Con', enchants: [null, nebular2, nebular3, nebular4] },
  { name: 'Star_Suit_Of_Crt', enchants: [null, nebular2, nebular3, nebular4] },
  { name: 'Star_Robe_Of_Spl', enchants: [null, nebular2, nebular3, nebular4] },
  { name: 'Star_Robe_Of_Wis', enchants: [null, nebular2, nebular3, nebular4] },

  { name: 'Thanos_Helm1_LT', enchants: [null, null, thanosHead3, thanosHead4] },
  { name: 'Thanos_Helm2_LT', enchants: [null, null, thanosHead3, thanosHead4] },
  { name: 'Thanos_Helm3_LT', enchants: [null, null, thanosHead3, thanosHead4] },
  { name: 'Thanos_Helm4_LT', enchants: [null, null, thanosHead3, thanosHead4] },

  { name: "Thanos_Boots1", enchants: [null, null, thanosBoot3, thanosBoot4] },
  { name: "Thanos_Boots2", enchants: [null, null, thanosBoot3, thanosBoot4] },
  { name: "Thanos_Boots3", enchants: [null, null, thanosBoot3, thanosBoot4] },
  { name: "Thanos_Boots4", enchants: [null, null, thanosBoot3, thanosBoot4] },

  { name: 'Signet_Of_Pow_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },
  { name: 'Signet_Of_Sta_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },
  { name: 'Signet_Of_Con_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },
  { name: 'Signet_Of_Crt_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },
  { name: 'Signet_Of_Spl_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },
  { name: 'Signet_Of_Wis_Star', enchants: [null, stellarAcc2, stellarAcc3, stellarAcc4] },

  { name: 'Signet_Of_Spring', enchants: [null, null, signetAcc3, signetAcc4] },
  { name: 'Signet_Of_Summer', enchants: [null, null, signetAcc3, signetAcc4] },
  { name: 'Signet_Of_Autumn', enchants: [null, null, signetAcc3, signetAcc4] },
  { name: 'Signet_Of_Winter', enchants: [null, null, signetAcc3, signetAcc4] },

  { name: "Circul_Of_Life_Spring", enchants: [null, cirSpringGarment2, cirSpringGarment3, cirSpringGarment4] },
  { name: "Circul_Of_Life_Summer", enchants: [null, cirAutumnSummer2, cirSpringGarment3, cirSpringGarment4] },
  { name: "Circul_Of_Life_Autumn", enchants: [null, cirAutumnGarment2, cirAutumnGarment3, cirAutumnGarment4] },
  { name: "Circul_Of_Life_Winter", enchants: [null, cirAutumnWinter2, cirSpringGarment3, cirSpringGarment4] },
  { name: "Season_Hood_Spring", enchants: [null, manSpringGarment2, manSpringGarment3, manSpringGarment4] },
  { name: "Season_Hood_Summer", enchants: [null, manAutumnSummer2, manSpringGarment3, manSpringGarment4] },
  { name: "Season_Hood_Autumn", enchants: [null, manAutumnGarment2, manAutumnGarment3, manAutumnGarment4] },
  { name: "Season_Hood_Winter", enchants: [null, manAutumnWinter2, manSpringGarment3, manSpringGarment4] },

  { name: 'Gray_W_Suits', enchants: [null, grayWolfArmor_slot2, grayWolfArmor_slot3, grayWolfArmor_slot4] },
  { name: 'Gray_W_Robe', enchants: [null, grayWolfArmor_slot2, grayWolfArmor_slot3, grayWolfArmor_slot4] },
  { name: 'Gray_W_Muffler', enchants: [null, grayWolfGarment_slot2, grayWolfGarment_slot3, grayWolfGarment_slot4] },
  { name: 'Gray_W_Manteau', enchants: [null, grayWolfGarment_slot2, grayWolfGarment_slot3, grayWolfGarment_slot4] },
  { name: 'Gray_W_Boots', enchants: [null, grayWolfBoot_slot2, grayWolfBoot_slot3, grayWolfBoot_slot4] },
  { name: 'Gray_W_Shoes', enchants: [null, grayWolfBoot_slot2, grayWolfBoot_slot3, grayWolfBoot_slot4] },
  { name: 'Gray_W_Pendant', enchants: [null, grayWolfAccR_slot2, grayWolfAccL_slot3, grayWolfAccL_slot4] },
  { name: 'Gray_W_Ring', enchants: [null, grayWolfAccL_slot2, grayWolfAccL_slot3, grayWolfAccL_slot4] },
  { name: 'Gray_W_Earing', enchants: [null, grayWolfAccR_slot2, grayWolfAccL_slot3, grayWolfAccL_slot4] },
  { name: 'Gray_W_Necklace', enchants: [null, grayWolfAccL_slot2, grayWolfAccL_slot3, grayWolfAccL_slot4] },
  { name: 'GreyW_S_Ring_TH', enchants: [null, grayWolfSoulRing_slot3, grayWolfSoulRing_slot3, grayWolfSoulRing_slot4] },

  { name: 'Officer_Cap_LT', enchants: [null, null, null, BaseState._3] },
  { name: 'Hero_Boots_LT', enchants: [null, heroBootLt2, heroBootLt3, heroBootLt4] },
  { name: 'Hero_Insignia', enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },

  { name: "Hero_Token_AG", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_WH", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_IG", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_CD", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_SHC", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_ABC", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_DK", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_BO", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_EM", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_TR", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_MT", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_IQ", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_SS", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_NW", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_SOA", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_SKE", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_SH", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },
  { name: "Hero_Token_HN", enchants: [null, heroBadge2, heroBootLt3, heroBootLt4] },

  { name: "Heroic_Hairband_AG_LT", enchants: [null, null, heroicHead3, heroicHead4] },
  { name: "Heroic_Hairband_DK_LT", enchants: [null, null, heroicHead3, heroicHead4] },
  { name: "Heroic_Hairband_SKE_LT", enchants: [null, null, heroicHead3, heroicHead4] },
  { name: "Heroic_Hairband_MT_LT", enchants: [null, null, heroicHead3, heroicHead4] },
  { name: "Heroic_Hairband_BO_LT", enchants: [null, null, heroicHead3, heroicHead4] },

  { name: 'Barmund_Flame_Armor', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Plain_Armor', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Death_Armor', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Ice_Armor', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Plain_Boots', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Flame_Boots', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Death_Boots', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Ice_Boots', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Plain_Hood', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Flame_Hood', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Death_Hood', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Ice_Hood', enchants: [null, null, varmundt3, varmundt4] },
  { name: 'Barmund_Soul_Ring', enchants: [null, null, varmundtAcc3, varmundtAcc4] },
  { name: 'Barmund_Venom_Ring', enchants: [null, null, varmundtAcc3, varmundtAcc4] },
  { name: 'Barmund_Temple_Ring', enchants: [null, null, varmundtAcc3, varmundtAcc4] },
  { name: "Soul_Rune_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },
  { name: "Venom_Rune_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },
  { name: "Temple_Rune_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },
  { name: "Soul_M_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },
  { name: "Venom_M_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },
  { name: "Temple_M_Ring", enchants: [null, varmundtHiAcc2, varmundtAcc3, varmundtAcc4] },

  { name: 'Flame_Rune_Armor', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Flame_Rune_Boots', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Flame_Rune_Hood', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Plain_Rune_Armor', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Plain_Rune_Boots', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Plain_Rune_Hood', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Ice_Rune_Armor', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Ice_Rune_Boots', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Ice_Rune_Hood', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Death_Rune_Armor', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Death_Rune_Boots', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },
  { name: 'Death_Rune_Hood', enchants: [null, flameRuneArmor2, varmundt3, varmundt4] },

  { name: 'Flame_E_R_Armor', enchants: [null, fieryEarthArmor2, fieryEarthArmor3, fieryEarthArmor4] },
  { name: 'Flame_E_R_Armor2', enchants: [null, fieryEarthArmor2, fieryEarthArmor3, fieryEarthArmor4] },
  { name: 'Ice_S_R_Suits', enchants: [null, icyStromArmor2, icyStromArmor3, icyStromArmor4] },
  { name: 'Ice_S_R_Suits2', enchants: [null, icyStromArmor2, icyStromArmor3, icyStromArmor4] },
  { name: 'Soul_P_R_Robe', enchants: [null, soulPurifyArmor2, soulPurifyArmor3, soulPurifyArmor4] },
  { name: 'Soul_P_R_Robe2', enchants: [null, soulPurifyArmor2, soulPurifyArmor3, soulPurifyArmor4] },
  { name: 'Corrupt_P_R_Cloth', enchants: [null, corruptedPoisonArmor2, corruptedPoisonArmor3, corruptedPoisonArmor4] },
  { name: 'Corrupt_P_R_Cloth2', enchants: [null, corruptedPoisonArmor2, corruptedPoisonArmor3, corruptedPoisonArmor4] },

  { name: "Mad_Bunny_K_LT", enchants: [null, null, madBunnyLt4, madBunnyLt4] },

  { name: 'Cannon_Rapier_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Kuroiro_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Boost_Lance_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Circuit_Board_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Rutilus_Stick_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'ElectricFox_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Burning_Knuckle_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Saphir_Hall_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Ultio_Spes_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Beam_Claymore_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Meuchler_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Blasti_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'Virtual_Bow_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'MH_P89_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'AC_B44_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },
  { name: 'HR_S55_AD', enchants: [null, null, oasdWeapon3, oasdWeapon4] },

  { name: 'Glacier_Helm_1', enchants: [null, issgardCrown2, issgardCrown3, issgardCrown4] },
  { name: 'Glacier_Helm_2', enchants: [null, issgardCrown2, issgardCrown3, issgardCrown4] },
  { name: 'Glacier_Helm_3', enchants: [null, issgardCrown2, issgardCrown3, issgardCrown4] },

  { name: 'Glacier_Armor', enchants: [null, glacierArmor2, glacierArmor3, glacierArmor4] },
  { name: 'Glacier_Robe', enchants: [null, glacierArmor2, glacierArmor3, glacierArmor4] },
  { name: 'Glacier_Manteau', enchants: [null, glacierGarment2, glacierGarment3, glacierGarment4] },
  { name: 'Glacier_Muffler', enchants: [null, glacierGarment2, glacierGarment3, glacierGarment4] },
  { name: 'Glacier_Shoes', enchants: [null, glacierBoot2, glacierBoot3, glacierBoot4] },
  { name: 'Glacier_Boots', enchants: [null, glacierBoot2, glacierBoot3, glacierBoot4] },
  { name: 'Glacier_Pendant', enchants: [null, glacierAcc2, glacierAcc3, glacierAccR4] },
  { name: 'Glacier_Necklace', enchants: [null, glacierAcc2, glacierAcc3, glacierAccR4] },
  { name: 'Glacier_Ring', enchants: [null, glacierAcc2, glacierAcc3, glacierAccL4] },
  { name: 'Glacier_Earring', enchants: [null, glacierAcc2, glacierAcc3, glacierAccL4] },

  { name: 'Glacier_Guard', enchants: [null, glacierGuard2, glacierGuard3, glacierGuard4] },

  { name: 'Glacier_Sword', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_B_Sword', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_R_Knife', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_B_Knife', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Axe', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Spear', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Book', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Wand', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Foxtail', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Knuckle', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Violin', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Whip', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Mace', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_M_Mace', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_T_Sword', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Katar', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_T_Axe', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Lance', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Staff', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Humma', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Bow', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Revolver', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Rifle', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Shotgun', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Gatling', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },
  { name: 'Glacier_Launcher', enchants: [glacierWea1, glacierWea2, glacierWea3, glacierWea4] },

  { name: 'D_Glacier_Armor', enchants: [null, dimGlaArmor2, dimGlaArmor3, dimGlaArmor4] },
  { name: 'D_Glacier_Robe', enchants: [null, dimGlaArmor2, dimGlaArmor3, dimGlaArmor4] },
  { name: 'D_Glacier_Manteau', enchants: [null, dimGlaGarment2, dimGlaGarment3, dimGlaGarment4] },
  { name: 'D_Glacier_Muffler', enchants: [null, dimGlaGarment2, dimGlaGarment3, dimGlaGarment4] },
  { name: 'D_Glacier_Boots', enchants: [null, dimGlaBoot2, dimGlaBoot3, dimGlaBoot4] },
  { name: 'D_Glacier_Shoes', enchants: [null, dimGlaBoot2, dimGlaBoot3, dimGlaBoot4] },

  { name: "D_Glacier_Sword", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_B_Sword", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_R_Knife", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_B_Knife", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Axe", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Spear", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Book", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Wand", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Foxtail", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Knuckle", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Violin", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Whip", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Mace", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_M_Mace", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_T_Sword", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Katar", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_T_Axe", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Lance", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Staff", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Humma", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Bow", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Revolver", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Rifle", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Shotgun", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Gatling", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },
  { name: "D_Glacier_Launcher", enchants: [null, dimWeapon2, dimWeapon3, dimWeapon4] },

  { name: "Viva_Adul_Hat_WL1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_WL2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SR1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SR2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_AB1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_AB2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SC1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SC2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RA1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RA2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_LG1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_LG2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_GC1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_GC2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SO1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SO2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RK1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RK2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_WM1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_WM2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_NC1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_NC2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_GN1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_GN2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_KO1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_KO2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RL1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_RL2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SP1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SP2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SJ1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SJ2", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SU1", enchants: [null, null, vivatusHead3, vivatusHead4] },
  { name: "Viva_Adul_Hat_SU2", enchants: [null, null, vivatusHead3, vivatusHead4] },

  { name: "Snowflower_Armor", enchants: [null, snowFwArmor2, snowFwArmor3, snowFwArmor4] },
  { name: "Snowflower_Robe", enchants: [null, snowFwArmor2, snowFwArmor3, snowFwArmor4] },
  { name: "Snowflower_Boots", enchants: [null, snowFwBoot2, snowFwBoot3, snowFwBoot4] },
  { name: "Snowflower_Shoes", enchants: [null, snowFwBoot2, snowFwBoot3, snowFwBoot4] },
  { name: "Snowflower_Manteau", enchants: [null, snowFwGarment2, snowFwGarment3, snowFwGarment4] },
  { name: "Snowflower_Muffler", enchants: [null, snowFwGarment2, snowFwGarment3, snowFwGarment4] },
  { name: "Snowflower_Pendant", enchants: [null, snowFwAccR2, snowFwAccR3, snowFwAccR4] },
  { name: "Snowflower_Necklace", enchants: [null, snowFwAccR2, snowFwAccR3, snowFwAccR4] },
  { name: "Snowflower_Ring", enchants: [null, snowFwAccL2, snowFwAccL3, snowFwAccL4] },
  { name: "Snowflower_Earring", enchants: [null, snowFwAccL2, snowFwAccL3, snowFwAccL4] },

  { name: "Solid_Claymore", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Edge", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Dagger", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Spear", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Manual", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Wand", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Rod", enchants: [null, null, crafted3, crafted4] },
  { name: "Solid_Staff", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Fist", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Lute", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Whip", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Fuuma", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Bow", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Pistol", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Rifle", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Shotgun", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Gatling", enchants: [null, null, crafted3, crafted4] },
  { name: "Precision_Grenade", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Nymph_Card", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Blade", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Dagger", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Edge", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Book", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Plant", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Cross", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Katar", enchants: [null, null, crafted3, crafted4] },
  { name: "Wicked_Axe", enchants: [null, null, crafted3, crafted4] },

  { name: "Fourth_1h_Nindo", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Edge", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Spear", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Book", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Rod", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Wand", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Sword", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Staff", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Sword", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Dagger", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Nindo2", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Manual", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Plant", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Mace", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Katar", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Axe", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Knuckle", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Lute", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_1h_Whip", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Fuuma", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Bh_Bow", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Revolver", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Rifle", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Shotgun", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Gatling", enchants: [null, null, crafted3, crafted4] },
  { name: "Fourth_Grenade", enchants: [null, null, crafted3, crafted4] },

  { name: "Unknown_Watch_SHC", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_HN", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_AC", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_SH", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_TT", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_HN2", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_AM", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },
  { name: "Unknown_Watch_EM", enchants: [null, unkWatch2, unkWatch34, unkWatch34] },

  { name: "GoodnEvil_Circlet_DK", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_IG", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_AG", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_EM", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_CD", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_IQ", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_MT", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_BO", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_SHC", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_ABC", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_WH", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_TR", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_SS", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_SKE", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_SOA", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_HN", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_SH", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_NW", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_NW2", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_NW3", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_NW4", enchants: [null, null, goodEvilHead3, goodEvilHead4] },
  { name: "GoodnEvil_Circlet_NW5", enchants: [null, null, goodEvilHead3, goodEvilHead4] },

  { name: "Destruction_Axe", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_Cursed_Sword", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Blood_Rapier", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_Guardian_Sword", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Underworld_Knife", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Sealed_Bible", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Darkness_Tablet", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Doom_Bible", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Soul_Harvest", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Darkness_Foxtail_Model", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Demonic_Claw", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Crime_Violine", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Crime_Whip", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Execution_Great_Sword", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "The_Reaper", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_Wing_Staff", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_Claw", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Dark_Angel_Ray_Bow", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devils_Bullet", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Screaming_Rifle", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Outlaw_Cursed_Shotgun", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "RG_5649", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_L_Launcher", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },

  { name: "Guardian_Saber", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Victory_Sword", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Holy_Light_Dagger", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Holy_Raise_Spear", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Orign_Of_Life", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Blessed_Bible", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Saint_Bringer", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Soul_Liberator", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Lightforce_Foxtail_Wand", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Light_Power_Harp", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Light_Power_Spark", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Punish_Hall", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Shining_Light_Katar", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Divine_Buster", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Luppiter_Spear", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Destiny_Staff", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Humma_Brilliance", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Angel_Wing_Bow", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Devil_Hunter", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Last_Dawn", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Road_Of_Glory", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Lighting_Splatter", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },
  { name: "Justice_Bomber", enchants: [null, null, sinsFateWeapon3, sinsFateWeapon4] },

  { name: 'FateSin_Boots_CD', enchants: [null, null, goodEvilBoot3_CD, goodEvilBoot4] },
  { name: 'FateSin_Boots_IQ', enchants: [null, null, goodEvilBoot3_IQ, goodEvilBoot4] },
  { name: 'FateSin_Boots_SOA', enchants: [null, null, goodEvilBoot3_SOA, goodEvilBoot4] },
  { name: 'FateSin_Boots_BO', enchants: [null, null, goodEvilBoot3_BO, goodEvilBoot4] },
  { name: 'FateSin_Boots_DK', enchants: [null, null, goodEvilBoot3_DK, goodEvilBoot4] },
  { name: 'FateSin_Boots_SH', enchants: [null, null, goodEvilBoot3_SH, goodEvilBoot4] },
  { name: 'FateSin_Boots_EM', enchants: [null, null, goodEvilBoot3_EM, goodEvilBoot4] },
  { name: 'FateSin_Boots_WH', enchants: [null, null, goodEvilBoot3_WH, goodEvilBoot4] },
  { name: 'FateSin_Boots_SKE', enchants: [null, null, goodEvilBoot3_SKE, goodEvilBoot4] },
  { name: 'FateSin_Boots_MT', enchants: [null, null, goodEvilBoot3_MT, goodEvilBoot4] },
  { name: 'FateSin_Boots_SHC', enchants: [null, null, goodEvilBoot3_SHC, goodEvilBoot4] },
  { name: 'FateSin_Boots_SS', enchants: [null, null, goodEvilBoot3_SS, goodEvilBoot4] },
  { name: 'FateSin_Boots_ABC', enchants: [null, null, goodEvilBoot3_ABC, goodEvilBoot4] },
  { name: 'FateSin_Boots_TR', enchants: [null, null, goodEvilBoot3_TR, goodEvilBoot4] },
  { name: 'FateSin_Boots_HN', enchants: [null, null, goodEvilBoot3_HN, goodEvilBoot4] },
  { name: 'FateSin_Boots_IG', enchants: [null, null, goodEvilBoot3_IG, goodEvilBoot4] },
  { name: 'FateSin_Boots_AG', enchants: [null, null, goodEvilBoot3_AG, goodEvilBoot4] },
  { name: 'FateSin_Boots_NW', enchants: [null, null, goodEvilBoot3_NW, goodEvilBoot4] },

  { name: 'Dolor_HatK_LT', enchants: [null, null, droopingLt3, droopingLt4] },
  { name: 'Red_Force_Pendant_LT', enchants: [null, null, redBlueLt3, redBlueLt4] },
  { name: 'Blue_Mental_Pendant_LT', enchants: [null, null, redBlueLt3, redBlueLt4] },

  { name: 'Mocadas_G_Sword', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_C_Sword', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Knife', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Axe', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Spellbooks', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Book', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Rod', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Foxtail', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Wand', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Knuckle', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Instrument', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Whip', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Judgement', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Hall', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Katar', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Spear', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Stem', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Bow', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Rifle', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Shotgun', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Gatling', enchants: [null, null, muqaddas3, muqaddas4] },
  { name: 'Mocadas_Launcher', enchants: [null, null, muqaddas3, muqaddas4] },

  { name: 'F_Ein_1HDAGGER', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HMAGGER', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HSWORD', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1H_Foxtail', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HSPEAR', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHSWORD', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HHAMMER', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHAXE', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HKNUCK', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HBOOK', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HWAND', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHSTAFF', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHHuuma', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHBOW', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_BHKATAR', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HGUN', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HWHIP', enchants: [null, null, plusWeapon3, plusWeapon4] },
  { name: 'F_Ein_1HLUTE', enchants: [null, null, plusWeapon3, plusWeapon4] },

  { name: 'Time_DM_R_Crown_DK', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_IG', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_MT', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_BO', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_SHC', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_ABC', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_AG', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_EM', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_CD', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_IQ', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_WH', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_TR', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_SS', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_NW', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_SKE', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_SOA', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_HN', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },
  { name: 'Time_DM_R_Crown_SH', enchants: [null, dimensionHead2, dimensionHead3, dimensionHead4] },

  { name: 'Dimen_IG_Sword', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_BO_Sword', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_HN_Sword', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_ABC_Knife', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_IG_Spear', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_EM_M_Book', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_EM_S_Book', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_CD_Bible', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SKE_M_Book', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SKE_S_Book', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_CD_Rod', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SOA_Stick', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SOA_Rod', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_HN_Rod', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SH_Foxtail', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SH_F_Model', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_IQ_Knuckle', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_IQ_Claw', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_TR_Vilolin', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_TR_Harp', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_TR_Ribbon', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_TR_Rope', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_MT_Mace', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_BO_Hall', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_DK_T_Sword', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SHC_Katar', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SHC_Cakram', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_MT_Axe', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_DK_Lance', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_AG_Staff', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_AG_Rod', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SS_Humma', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_SS_Wheel', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_ABC_Bow', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_WH_C_Bow', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_WH_Bow', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_NW_Rifle', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },
  { name: 'Dimen_NW_Launcher', enchants: [null, null, dimensionWeapon3, dimensionWeapon4] },

  { name: 'Dimmension_W_Key', enchants: [null, null, dimensionAcc3, dimensionAcc4] },
  { name: 'Dimmension_W_Padlock', enchants: [null, null, dimensionAcc3, dimensionAcc4] },
  { name: 'Dimmension_W_Keyring', enchants: [null, null, dimensionAcc3, dimensionAcc4] },

  { name: 'FuriousCirclet_WH', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_CD', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_SKE', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_DK', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_ABC', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_SH', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_IG', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_SHC', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_SS', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_MT', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_EM', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_SOA', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_TR', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_BO', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_HN', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_AG', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_IQ', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },
  { name: 'FuriousCirclet_NW', enchants: [null, null, furiousHeadUp3, furiousHeadUp4] },

  { name: 'FuriousBoots', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Lapier_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'SharpSword_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'WhiteSword_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Demonius_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Demonsword_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'RightShape_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  // { name: 'LeftShape_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'OverSpear_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Lance_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'SaintBook_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'SunBook_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'MoonBook_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'MasterSpellBook_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Grimoire_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'SaintWand_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Foxtail_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Setaria_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Soul_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'SpiritStick_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Stick_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Specter_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'GaleClaw_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Exterminate_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'MetalVilolin_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Harp_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'MetalWhip_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Whip_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Hammer_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Slayer_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Impact_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Humma_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'GiganticAxe_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Trident_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Flame_Staff_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'WheelHumma_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'StormBow_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'TornadoBow_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Rifle_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },
  { name: 'Gatling_Furious', enchants: [null, null, furiousWeaponUp3, furiousWeaponUp4] },

  { name: 'Gaebolg_Armor', enchants: [null, gbArmor2, gbArmor3, gbArmor4] },
  { name: 'Gaebolg_Robe', enchants: [null, gbArmor2, gbArmor3, gbArmor4] },
  { name: 'Gaebolg_Manteau', enchants: [null, gbGarment2, gbGarment3, gbGarment4] },
  { name: 'Gaebolg_Muffler', enchants: [null, gbGarment2, gbGarment3, gbGarment4] },
  { name: 'Gaebolg_Boots', enchants: [null, gbBoot2, gbBoot3, gbBoot4] },
  { name: 'Gaebolg_Shoes', enchants: [null, gbBoot2, gbBoot3, gbBoot4] },
  { name: 'Gaebolg_Ring', enchants: [null, gbAcc2, gbAcc3, gbAcc4] },
  { name: 'Gaebolg_Glove', enchants: [null, gbAcc2, gbAcc3, gbAcc4] },
  { name: 'Gaebolg_Earring', enchants: [null, gbAcc2, gbAcc3, gbAcc4] },
  { name: 'Gaebolg_Necklace', enchants: [null, gbAcc2, gbAcc3, gbAcc4] },

  { name: "WK_Mantle_Melee_TH", enchants: [null, whiteKnight2, whiteKnight34, whiteKnight34] },
  { name: "WK_Mantle_Range_TH", enchants: [null, whiteKnight2, whiteKnight34, whiteKnight34] },
  { name: "WK_Mantle_Magic_TH", enchants: [null, whiteKnight2, whiteKnight34, whiteKnight34] },
  { name: "WK_Mantle_All_TH_LT", enchants: [null, whiteKnight2, whiteKnight34, whiteKnight34] },

  { name: "aegis_Kankrai", enchants: [null, rockPaperScissor, rockPaperScissor, rockPaperScissor] },
  { name: "aegis_Khon", enchants: [null, rockPaperScissor, rockPaperScissor, rockPaperScissor] },
  { name: "aegis_Kradat", enchants: [null, rockPaperScissor, rockPaperScissor, rockPaperScissor] },
  { name: "Mob_Scarf_LT", enchants: [null, rockPaperScissor, rockPaperScissor, rockPaperScissor] },

  { name: "Volcano_H_Ring_TH", enchants: [null, ['HeroAcc_AG1'], ['HeroAcc_WL1'], heroRing4] },
  { name: "Dragon_Order_TH", enchants: [null, ['HeroAcc_DK1'], ['HeroAcc_RK1'], heroRing4] },
  { name: "Foot_Stamp_TH", enchants: [null, ['HeroAcc_SKE1'], ['HeroAcc_SJ1'], heroRing4] },
  { name: "Laser_Hero_Ring_TH", enchants: [null, ['HeroAcc_MT1'], ['HeroAcc_MC1'], heroRing4] },
  { name: "Dragon_Plant_TH", enchants: [null, ['HeroAcc_BO1'], ['HeroAcc_GN1'], heroRing4] },

  { name: 'Katar_Of_Infinite', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_SS_Dagger1', enchants: [null, null, timeGap3, timeGap4] },
  // { name: 'Time_Gap_SS_Dagger2', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_BO_Blade', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_SHC_Dagger1', enchants: [null, null, timeGap3, timeGap4] },
  // { name: 'Time_Gap_SHC_Dagger2', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_Spear_IG', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_SKE_Book', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_EM_S_Book', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_HN_Staff', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_SOA_Rod', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_CD_Staff', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_SH_Foxtail', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_IQ_Knuckle', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_TR_Vilolin', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_TR_Ribbon', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_MT_Axe', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_DK_Spear', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_Staff_AG', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_WH_Bow', enchants: [null, null, timeGap3, timeGap4] },
  { name: 'Time_Gap_Revolver_NW', enchants: [null, null, timeGap3, timeGap4] },

  { name: 'Yorscalp_Armor', enchants: [null, yorscalpArmor2, yorscalpArmor3, yorscalpArmor4] },
  { name: 'Yorscalp_Robe', enchants: [null, yorscalpArmor2, yorscalpArmor3, yorscalpArmor4] },
  { name: 'Yorscalp_Manteau', enchants: [null, yorscalpGarment2, yorscalpGarment3, yorscalpGarment4] },
  { name: 'Yorscalp_Muffler', enchants: [null, yorscalpGarment2, yorscalpGarment3, yorscalpGarment4] },
  { name: 'Yorscalp_Boots', enchants: [null, yorscalpBoot2, yorscalpBoot3, yorscalpBoot4] },
  { name: 'Yorscalp_Shoes', enchants: [null, yorscalpBoot2, yorscalpBoot3, yorscalpBoot4] },
  { name: 'Yorscalp_Ring', enchants: [null, yorscalpAcc2, yorscalpAcc3, yorscalpAcc4] },
  { name: 'Yorscalp_Glove', enchants: [null, yorscalpAcc2, yorscalpAcc3, yorscalpAcc4] },
  { name: 'Yorscalp_Earring', enchants: [null, yorscalpAcc2, yorscalpAcc3, yorscalpAcc4] },
  { name: 'Yorscalp_Necklace', enchants: [null, yorscalpAcc2, yorscalpAcc3, yorscalpAcc4] },
  { name: 'Yorscalp_P_Circlet', enchants: [null, yorscalpHeadUpper2, yorscalpHeadUpper3, yorscalpHeadUpper4] },
  { name: 'Yorscalp_M_Circlet', enchants: [null, yorscalpHeadUpper2, yorscalpHeadUpper3, yorscalpHeadUpper4] },

  { name: 'Royal_H_Mail_A', enchants: [null, royalHArmor2, royalHArmor3, royalHArmor4] },
  { name: 'Royal_H_Mail_B', enchants: [null, royalHArmor2, royalHArmor3, royalHArmor4] },
  { name: 'Royal_H_Manteau_A', enchants: [null, null, royalHGarment3, royalHGarment4] },
  { name: 'Royal_H_Manteau_B', enchants: [null, null, royalHGarment3, royalHGarment4] },
  { name: 'Royal_H_Boots_A', enchants: [null, null, royalHBoot3, royalHBoot4] },
  { name: 'Royal_H_Boots_B', enchants: [null, null, royalHBoot3, royalHBoot4] },

  { name: "Angel_R_Wing_RD", enchants: [null, null, angelRibbonWing3, angelRibbonWing4] },
  { name: "Angel_R_Wing_WH", enchants: [null, null, angelRibbonWing3, angelRibbonWing4] },
  { name: "Angel_R_Wing_RD_LT", enchants: [null, null, angelRibbonWing3, angelRibbonWing4] },
  { name: "Angel_R_Wing_WH_LT", enchants: [null, null, angelRibbonWing3, angelRibbonWing4] },

  { name: "5th_Mask_Melee", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "5th_Mask_Magic", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "5th_Mask_Range", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "Karasu_TenguMask_", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "WishingTree_", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "CherubCoronet_", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "Clown_Smiling_", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "Imperial_Earwing_", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "D_Protect_Shields", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "Ear_Of_Abyss_TH", enchants: [null, anni5th, anni5th, anni5th] },
  { name: "Raven_Of_Tomb_LT", enchants: [null, anni5th, anni5th, anni5th] },

  { name: "S_Master_Weapon", enchants: [null, null, mShadow3, mShadow4] },
  { name: "S_Master_Shield", enchants: [null, null, mShadow3, mShadow4] },
  { name: "S_DK_Armor", enchants: [null, null, mShadowDK3, mShadowAllClass4] },
  { name: "S_DK_Shoes", enchants: [null, null, mShadowDK3, mShadowAllClass4] },
  { name: "S_DK_Earring", enchants: [null, null, mShadowDK3, mShadowAllClass4] },
  { name: "S_DK_Pendant", enchants: [null, null, mShadowDK3, mShadowAllClass4] },
  { name: "S_IG_Armor", enchants: [null, null, mShadowIG3, mShadowAllClass4] },
  { name: "S_IG_Shoes", enchants: [null, null, mShadowIG3, mShadowAllClass4] },
  { name: "S_IG_Earring", enchants: [null, null, mShadowIG3, mShadowAllClass4] },
  { name: "S_IG_Pendant", enchants: [null, null, mShadowIG3, mShadowAllClass4] },
  { name: "S_SHC_Armor", enchants: [null, null, mShadowSHC3, mShadowAllClass4] },
  { name: "S_SHC_Shoes", enchants: [null, null, mShadowSHC3, mShadowAllClass4] },
  { name: "S_SHC_Earring", enchants: [null, null, mShadowSHC3, mShadowAllClass4] },
  { name: "S_SHC_Pendant", enchants: [null, null, mShadowSHC3, mShadowAllClass4] },
  { name: "S_ABC_Armor", enchants: [null, null, mShadowABC3, mShadowAllClass4] },
  { name: "S_ABC_Shoes", enchants: [null, null, mShadowABC3, mShadowAllClass4] },
  { name: "S_ABC_Earring", enchants: [null, null, mShadowABC3, mShadowAllClass4] },
  { name: "S_ABC_Pendant", enchants: [null, null, mShadowABC3, mShadowAllClass4] },
  { name: "S_CD_Armor", enchants: [null, null, mShadowCAR3, mShadowAllClass4] },
  { name: "S_CD_Shoes", enchants: [null, null, mShadowCAR3, mShadowAllClass4] },
  { name: "S_CD_Earring", enchants: [null, null, mShadowCAR3, mShadowAllClass4] },
  { name: "S_CD_Pendant", enchants: [null, null, mShadowCAR3, mShadowAllClass4] },
  { name: "S_IQ_Armor", enchants: [null, null, mShadowIQ3, mShadowAllClass4] },
  { name: "S_IQ_Shoes", enchants: [null, null, mShadowIQ3, mShadowAllClass4] },
  { name: "S_IQ_Earring", enchants: [null, null, mShadowIQ3, mShadowAllClass4] },
  { name: "S_IQ_Pendant", enchants: [null, null, mShadowIQ3, mShadowAllClass4] },
  { name: "S_MT_Armor", enchants: [null, null, mShadowMEI3, mShadowAllClass4] },
  { name: "S_MT_Shoes", enchants: [null, null, mShadowMEI3, mShadowAllClass4] },
  { name: "S_MT_Earring", enchants: [null, null, mShadowMEI3, mShadowAllClass4] },
  { name: "S_MT_Pendant", enchants: [null, null, mShadowMEI3, mShadowAllClass4] },
  { name: "S_BO_Armor", enchants: [null, null, mShadowBIO3, mShadowAllClass4] },
  { name: "S_BO_Shoes", enchants: [null, null, mShadowBIO3, mShadowAllClass4] },
  { name: "S_BO_Earring", enchants: [null, null, mShadowBIO3, mShadowAllClass4] },
  { name: "S_BO_Pendant", enchants: [null, null, mShadowBIO3, mShadowAllClass4] },
  { name: "S_WH_Armor", enchants: [null, null, mShadowWH3, mShadowAllClass4] },
  { name: "S_WH_Shoes", enchants: [null, null, mShadowWH3, mShadowAllClass4] },
  { name: "S_WH_Earring", enchants: [null, null, mShadowWH3, mShadowAllClass4] },
  { name: "S_WH_Pendant", enchants: [null, null, mShadowWH3, mShadowAllClass4] },
  { name: "S_TR_Armor", enchants: [null, null, mShadowTVTB3, mShadowAllClass4] },
  { name: "S_TR_Shoes", enchants: [null, null, mShadowTVTB3, mShadowAllClass4] },
  { name: "S_TR_Earring", enchants: [null, null, mShadowTVTB3, mShadowAllClass4] },
  { name: "S_TR_Pendant", enchants: [null, null, mShadowTVTB3, mShadowAllClass4] },
  { name: "S_AG_Armor", enchants: [null, null, mShadowAM3, mShadowAllClass4] },
  { name: "S_AG_Shoes", enchants: [null, null, mShadowAM3, mShadowAllClass4] },
  { name: "S_AG_Earring", enchants: [null, null, mShadowAM3, mShadowAllClass4] },
  { name: "S_AG_Pendant", enchants: [null, null, mShadowAM3, mShadowAllClass4] },
  { name: "S_EM_Armor", enchants: [null, null, mShadowEM3, mShadowAllClass4] },
  { name: "S_EM_Shoes", enchants: [null, null, mShadowEM3, mShadowAllClass4] },
  { name: "S_EM_Earring", enchants: [null, null, mShadowEM3, mShadowAllClass4] },
  { name: "S_EM_Pendant", enchants: [null, null, mShadowEM3, mShadowAllClass4] },
  { name: "S_NW_Armor", enchants: [null, null, mShadowNW3, mShadowAllClass4] },
  { name: "S_NW_Shoes", enchants: [null, null, mShadowNW3, mShadowAllClass4] },
  { name: "S_NW_Earring", enchants: [null, null, mShadowNW3, mShadowAllClass4] },
  { name: "S_NW_Pendant", enchants: [null, null, mShadowNW3, mShadowAllClass4] },
  { name: "S_SH_Armor", enchants: [null, null, mShadowSH3, mShadowAllClass4] },
  { name: "S_SH_Shoes", enchants: [null, null, mShadowSH3, mShadowAllClass4] },
  { name: "S_SH_Earring", enchants: [null, null, mShadowSH3, mShadowAllClass4] },
  { name: "S_SH_Pendant", enchants: [null, null, mShadowSH3, mShadowAllClass4] },
  { name: "S_SS_Armor", enchants: [null, null, mShadowSS3, mShadowAllClass4] },
  { name: "S_SS_Shoes", enchants: [null, null, mShadowSS3, mShadowAllClass4] },
  { name: "S_SS_Earring", enchants: [null, null, mShadowSS3, mShadowAllClass4] },
  { name: "S_SS_Pendant", enchants: [null, null, mShadowSS3, mShadowAllClass4] },
  { name: "S_SKE_Armor", enchants: [null, null, mShadowSKY3, mShadowAllClass4] },
  { name: "S_SKE_Shoes", enchants: [null, null, mShadowSKY3, mShadowAllClass4] },
  { name: "S_SKE_Earring", enchants: [null, null, mShadowSKY3, mShadowAllClass4] },
  { name: "S_SKE_Pendant", enchants: [null, null, mShadowSKY3, mShadowAllClass4] },
  { name: "S_SOA_Armor", enchants: [null, null, mShadowSA3, mShadowAllClass4] },
  { name: "S_SOA_Shoes", enchants: [null, null, mShadowSA3, mShadowAllClass4] },
  { name: "S_SOA_Earring", enchants: [null, null, mShadowSA3, mShadowAllClass4] },
  { name: "S_SOA_Pendant", enchants: [null, null, mShadowSA3, mShadowAllClass4] },
  { name: "S_HN_Armor", enchants: [null, null, mShadowHYPER3, mShadowAllClass4] },
  { name: "S_HN_Shoes", enchants: [null, null, mShadowHYPER3, mShadowAllClass4] },
  { name: "S_HN_Earring", enchants: [null, null, mShadowHYPER3, mShadowAllClass4] },
  { name: "S_HN_Pendant", enchants: [null, null, mShadowHYPER3, mShadowAllClass4] },

  { name: "S_Full_Power_Armor", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Full_Power_Shoes", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Full_Rate_Armor", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Full_Rate_Shoes", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Focusing_Pendant", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Focusing_Earring", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Stout_Pendant", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Stout_Earring", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Full_Spell_Armor", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Full_Spell_Shoes", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Centering_Pendant", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Centering_Earring", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Witty_Pendant", enchants: [null, null, traitShadow3, traitShadow4] },
  { name: "S_Witty_Earring", enchants: [null, null, traitShadow3, traitShadow4] },

  { name: "S_BP8_Melee_W", enchants: [null, null, nebularShadow2, nebularShadow34] },
  { name: "S_BP8_Melee_S", enchants: [null, null, nebularShadow2, nebularShadow34] },
  { name: "S_BP8_Range_W", enchants: [null, null, nebularShadow2, nebularShadow34] },
  { name: "S_BP8_Range_S", enchants: [null, null, nebularShadow2, nebularShadow34] },
  { name: "S_BP8_Magic_W", enchants: [null, null, nebularShadow2, nebularShadow34] },
  { name: "S_BP8_Magic_S", enchants: [null, null, nebularShadow2, nebularShadow34] },

  { name: "Nebula_Nec_LT_TH", enchants: [null, null, nebularPendant3, nebularPendant4] },
];

Object.freeze(EnchantTable);

const map = new Map(EnchantTable.map((a) => [a.name, a.enchants]));

export const getEnchants = (name) => {
  return map.get(name);
};

/** Every weapon Snow enchants in Malangdo, as a set of item ids (see MALANGDO_WEAPON_IDS). */
const malangdoWeapons = new Set(Object.values(MALANGDO_WEAPON_IDS).flat());

/**
 * The Malangdo enchant slots for a weapon, or undefined when Snow does not take it.
 *
 * Two enchants, in the last two positions — except a 3-slot weapon, which the wiki
 * says "receberá somente 1 encanto". Matching by id rather than by aegisName is what
 * makes this reach the ~1000 items whose aegisName is the client's Korean resource
 * name; see malangdo_weapons.ts.
 */
export const getMalangdoEnchants = (id: number, slots = 0): EntTable['enchants'] | undefined => {
  if (!malangdoWeapons.has(id)) return undefined;
  return slots >= 3 ? [null, null, null, malangdo] : [null, null, malangdo, malangdo];
};
