import { describe, expect, it } from 'vitest';
import { compressToEncodedURIComponent } from 'src/app/core/uri-compression';
import { createMainModel } from 'src/app/utils';
import { decodeBuild, decodeShared, dropDefaults, encodeBuild } from './share-codec';

const preset = { class: 4261, level: 230, jobLevel: 50, weapon: 700016, weaponRefine: 11, str: 0, agi: 0 };

describe('dropDefaults', () => {
  it('drops defaults but keeps the always-keep set', () => {
    expect(dropDefaults(preset, new Set(['class', 'level', 'jobLevel']))).toEqual({
      class: 4261,
      level: 230,
      jobLevel: 50,
      weapon: 700016,
      weaponRefine: 11,
    });
  });

  it('drops empty arrays and objects, keeps populated ones', () => {
    expect(dropDefaults({ a: [], b: [0, 0], c: [0, 5], d: {}, e: { x: 1 }, f: '' })).toEqual({ c: [0, 5], e: { x: 1 } });
  });

  it('tolerates null/undefined input', () => {
    expect(dropDefaults(null)).toEqual({});
    expect(dropDefaults(undefined)).toEqual({});
  });
});

describe('the reserved comparison key', () => {
  it('cannot collide with a real model field', () => {
    // The forward-compat guarantee rests on `__cmp` being invisible to
    // setModelByJSONString, which iterates createMainModel()'s own keys.
    expect(Object.keys(createMainModel())).not.toContain('__cmp');
  });
});

/**
 * The slot highlights ride the preset itself rather than a reserved key: the map is a
 * plain model field with an empty default, which `dropDefaults` already knows to drop.
 * The names a player gives the colours are deliberately NOT here — they stay in the
 * browser, so a link never renames the reader's own palette.
 */
describe('slot highlight colours in a token', () => {
  it('costs an unmarked build nothing', () => {
    expect(encodeBuild({ ...preset, slotColors: {} })).toBe(encodeBuild(preset));
  });

  it('carries the marked slots through a round trip', () => {
    const out = decodeShared(encodeBuild({ ...preset, slotColors: { weapon: 'azul', armor: 'rosa' } }));
    expect(out?.preset.slotColors).toEqual({ weapon: 'azul', armor: 'rosa' });
  });
});

describe('encodeBuild / decodeShared', () => {
  it('round-trips a build with no comparison', () => {
    const out = decodeShared(encodeBuild(preset));
    expect(out?.preset).toEqual({ class: 4261, level: 230, jobLevel: 50, weapon: 700016, weaponRefine: 11 });
    expect(out?.compare).toBeNull();
  });

  it('round-trips a build with a comparison', () => {
    const compare = { itemNames: ['weapon', 'armor'], model2: { weapon: 1291, weaponRefine: 9, rawOptionTxts: [] } };
    const out = decodeShared(encodeBuild(preset, compare));

    expect(out?.compare).toEqual({ itemNames: ['weapon', 'armor'], model2: { weapon: 1291, weaponRefine: 9 } });
    // the build itself is unaffected by the comparison riding along
    expect(out?.preset).toEqual(decodeShared(encodeBuild(preset))?.preset);
  });

  it('round-trips a stats comparison, with or without compared slots', () => {
    const statsOnly = { itemNames: [], model2: { level: 250, str: 120, pow: 60 }, stats: true };
    expect(decodeShared(encodeBuild(preset, statsOnly))?.compare).toEqual(statsOnly);

    const both = { itemNames: ['weapon'], model2: { weapon: 1291, level: 250 }, stats: true };
    expect(decodeShared(encodeBuild(preset, both))?.compare).toEqual(both);
  });

  it('round-trips an Auto-conjuração-only comparison with independent copied skills', () => {
    const autoCastOnly = {
      itemNames: [],
      model2: { autoCastSelections: { plagiarism: 83, reproduce: 2213 } },
      autoCast: true,
    };
    expect(decodeShared(encodeBuild(preset, autoCastOnly))?.compare).toEqual(autoCastOnly);
  });

  it('reads a comparison written before stats could be compared as gear-only', () => {
    const token = compressToEncodedURIComponent(JSON.stringify({ ...preset, __cmp: { i: ['weapon'], m: { weapon: 1 } } })).replace(/\+/g, '.');
    expect(decodeShared(token)?.compare).toEqual({ itemNames: ['weapon'], model2: { weapon: 1 } });
  });

  it('keeps tokens for uncompared builds byte-identical to the no-comparison encoding', () => {
    // Guards the wire format: adding the comparison must cost nothing when unused,
    // so every link shared before this change still encodes the same way.
    const bare = encodeBuild(preset);
    expect(encodeBuild(preset, null)).toBe(bare);
    expect(encodeBuild(preset, undefined)).toBe(bare);
    expect(encodeBuild(preset, { itemNames: [], model2: { weapon: 1 } })).toBe(bare);
  });

  it('sparse-ifies model2 rather than carrying its ~180 default fields', () => {
    const fat = { itemNames: ['weapon'], model2: { weapon: 1291, armor: 0, shield: null, boot: 0, rawOptionTxts: [] } };
    const lean = { itemNames: ['weapon'], model2: { weapon: 1291 } };
    expect(encodeBuild(preset, fat)).toBe(encodeBuild(preset, lean));
  });

  it('sanitizes a corrupt comparison to null instead of throwing', () => {
    for (const cmp of [{ i: 'nope', m: {} }, { i: [], m: {} }, { i: ['weapon'] }, { i: ['weapon'], m: 'x' }, 'junk', 7]) {
      const token = compressToEncodedURIComponent(JSON.stringify({ ...preset, __cmp: cmp })).replace(/\+/g, '.');
      const out = decodeShared(token);
      expect(out?.compare).toBeNull();
      expect(out?.preset['class']).toBe(4261);
    }
  });

  it('returns null for absent or invalid tokens', () => {
    expect(decodeShared(null)).toBeNull();
    expect(decodeShared(undefined)).toBeNull();
    expect(decodeShared('')).toBeNull();
    expect(decodeShared('not-a-real-token')).toBeNull();
  });
});

describe('decodeBuild', () => {
  it('still returns just the preset, with the comparison key stripped', () => {
    const compare = { itemNames: ['weapon'], model2: { weapon: 1291 } };
    const build = decodeBuild(encodeBuild(preset, compare));

    expect(build).toEqual({ class: 4261, level: 230, jobLevel: 50, weapon: 700016, weaponRefine: 11 });
    expect(Object.keys(build ?? {})).not.toContain('__cmp');
  });

  it('reads a token written before the comparison existed', () => {
    const legacy = compressToEncodedURIComponent(JSON.stringify({ class: 4261, level: 230, jobLevel: 50 })).replace(/\+/g, '.');
    expect(decodeBuild(legacy)).toEqual({ class: 4261, level: 230, jobLevel: 50 });
  });
});

describe('the attack rotation in a share token', () => {
  const withRotation = { ...preset, selectedAtkSkill: 'Solar Kick==7', rotation: ['Solar Kick==7', 'Sunset Blast==5', '__basic'] };

  it('carries a real rotation through the round trip, order and duplicates intact', () => {
    const rotation = ['Lunar Eclipse==7', 'Solar Kick==7', 'Sunset Blast==5', 'Solar Kick==7', '__basic'];
    const build = decodeBuild(encodeBuild({ ...preset, rotation }));

    expect(build?.['rotation']).toEqual(rotation);
  });

  it('keeps ataque básico, which is not a catalog value', () => {
    expect(decodeBuild(encodeBuild(withRotation))?.['rotation']).toEqual(withRotation.rotation);
  });

  it('leaves the rotation out entirely when it is empty', () => {
    // createMainModel defaults it to [], and dropDefaults strips empty arrays — so a
    // build that never touched the rotation costs the token nothing.
    const build = decodeBuild(encodeBuild({ ...preset, rotation: [] }));

    expect(build).not.toHaveProperty('rotation');
  });

  it('a token written before rotations existed still decodes', () => {
    const legacy = compressToEncodedURIComponent(
      JSON.stringify({ class: 4261, level: 230, jobLevel: 50, selectedAtkSkill: 'Solar Kick==7' }),
    ).replace(/\+/g, '.');

    const build = decodeBuild(legacy);
    expect(build).not.toHaveProperty('rotation');
    // setModelByJSONString then migrates the missing key to a rotation of one; see
    // rotation.spec.ts for normalizeRotation's half of that contract.
    expect(build?.['selectedAtkSkill']).toBe('Solar Kick==7');
  });
});
