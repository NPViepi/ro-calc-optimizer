import { describe, expect, it } from 'vitest';
import { defenderReductionMultiplier, defenderReductionSteps, pvpChannelOf, woeFleeMultiplier, woeGlobalMultiplier } from './pvp';

describe('pvp reduction math', () => {
  describe('woeGlobalMultiplier — Luís validated table (docs/pvp.md §2)', () => {
    it('open PVP applies no castle reduction on any channel', () => {
      expect(woeGlobalMultiplier('pvp', 'phys_melee')).toBe(1);
      expect(woeGlobalMultiplier('pvp', 'phys_ranged')).toBe(1);
      expect(woeGlobalMultiplier('pvp', 'skill')).toBe(1);
    });

    it('normal castle: melee −90%, ranged −95%, skills −90% (18/08/2026 patch)', () => {
      expect(woeGlobalMultiplier('woe', 'phys_melee')).toBe(0.1);
      expect(woeGlobalMultiplier('woe', 'phys_ranged')).toBe(0.05);
      expect(woeGlobalMultiplier('woe', 'skill')).toBe(0.1);
      // 1kk asura → 100k inside a castle (it was 300k before the patch)
      expect(1_000_000 * woeGlobalMultiplier('woe', 'skill')).toBe(100_000);
    });

    it('TE castle: same numbers as the normal castle since the patch', () => {
      expect(woeGlobalMultiplier('woe-te', 'phys_melee')).toBe(0.1);
      expect(woeGlobalMultiplier('woe-te', 'phys_ranged')).toBe(0.05);
      expect(woeGlobalMultiplier('woe-te', 'skill')).toBe(0.1);
    });

    it('mode none is a no-op', () => {
      expect(woeGlobalMultiplier('none', 'skill')).toBe(1);
    });
  });

  describe('woeFleeMultiplier', () => {
    it('reduces target flee 20% inside both castle modes, not open PVP', () => {
      expect(woeFleeMultiplier('woe')).toBe(0.8);
      expect(woeFleeMultiplier('woe-te')).toBe(0.8);
      expect(woeFleeMultiplier('pvp')).toBe(1);
      expect(woeFleeMultiplier('none')).toBe(1);
    });
  });

  describe('pvpChannelOf — only basic attacks split melee/ranged; all skills are skill', () => {
    it('classifies basic attacks by range', () => {
      expect(pvpChannelOf({ isSkill: false, isMelee: true })).toBe('phys_melee');
      expect(pvpChannelOf({ isSkill: false, isMelee: false })).toBe('phys_ranged');
    });
    it('classifies any skill as skill regardless of range', () => {
      expect(pvpChannelOf({ isSkill: true, isMelee: true })).toBe('skill');
      expect(pvpChannelOf({ isSkill: true, isMelee: false })).toBe('skill');
    });
  });

  describe('defenderReductionMultiplier', () => {
    const base = {
      dmgType: 'physical' as const,
      attackerRace: 'player_human',
      attackerElement: 'neutral',
      attackerSize: 'm' as const,
      attackerType: 'normal' as const,
    };

    it('no defensive gear → no reduction', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: {} })).toBe(1);
    });

    it('Thanatos-mask shape: dmg_taken_all 5% reduces both phys and magic', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: { dmg_taken_all: 5 } })).toBeCloseTo(0.95, 10);
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', bonus: { dmg_taken_all: 5 } })).toBeCloseTo(0.95, 10);
    });

    it('dmg_taken_physical only applies to physical', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: { dmg_taken_physical: 10 } })).toBeCloseTo(0.9, 10);
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', bonus: { dmg_taken_physical: 10 } })).toBe(1);
    });

    it('subrace matches the attacker race, not other races', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: { subrace_player_human: 20 } })).toBeCloseTo(0.8, 10);
      expect(defenderReductionMultiplier({ ...base, attackerRace: 'player_doram', bonus: { subrace_player_human: 20 } })).toBe(1);
    });

    it('categories combine multiplicatively; values within a category sum', () => {
      // subele_all 10 + subele_neutral 10 = 20% ele, plus dmg_taken_all 5%
      const m = defenderReductionMultiplier({ ...base, bonus: { subele_all: 10, subele_neutral: 10, dmg_taken_all: 5 } });
      expect(m).toBeCloseTo(0.8 * 0.95, 10);
    });

    it('a single category is clamped so it cannot flip damage negative', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: { dmg_taken_all: 150 } })).toBe(0);
    });

    it('subsize matches the attacker size and sums _all with the size', () => {
      expect(defenderReductionMultiplier({ ...base, bonus: { subsize_all: 10, subsize_m: 15 } })).toBeCloseTo(0.75, 10);
      expect(defenderReductionMultiplier({ ...base, bonus: { subsize_l: 25 } })).toBe(1);
    });

    it('subsize_*_physical / _magical only apply to their own damage type', () => {
      const phys = { subsize_m_physical: 10 };
      expect(defenderReductionMultiplier({ ...base, bonus: phys })).toBeCloseTo(0.9, 10);
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', bonus: phys })).toBe(1);

      const magic = { subsize_all_magical: 20 };
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', bonus: magic })).toBeCloseTo(0.8, 10);
      expect(defenderReductionMultiplier({ ...base, bonus: magic })).toBe(1);
    });

    it('the typed size keys sum into the same size category as the untyped ones', () => {
      const bonus = { subsize_all: 5, subsize_m: 10, subsize_m_physical: 10, subsize_all_physical: 5 };
      // one category: 5 + 10 + 10 + 5 = 30
      expect(defenderReductionMultiplier({ ...base, bonus })).toBeCloseTo(0.7, 10);
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', bonus })).toBeCloseTo(0.85, 10);
    });

    /**
     * `subrace_all` is the client's "Resistência a todas as raças de monstros" — the
     * pt-BR race vocabulary keeps the monster world and the player world apart
     * (docs/pvp.md §2: *Humanoide* is a mob, *Humano* is a player), so the line never
     * covers an attacking player. It used to, which over-credited every item carrying
     * it in PVP: U-Total (29542), the three Orbe Lupino - Total (310579-581), 400075
     * and the Automatron P-Total (310112).
     */
    it('subrace_all does not reduce a player attacker — it is monster races only', () => {
      const bonus = { subrace_all: 25 };

      expect(defenderReductionMultiplier({ ...base, attackerRace: 'player_human', bonus })).toBe(1);
      expect(defenderReductionMultiplier({ ...base, attackerRace: 'player_doram', bonus })).toBe(1);
    });

    it('leaves the player-race keys as the only ones that cut a player hit', () => {
      const bonus = { subrace_all: 25, subrace_player_human: 10 };

      expect(defenderReductionMultiplier({ ...base, attackerRace: 'player_human', bonus })).toBeCloseTo(0.9, 10);
      // …and a Doram attacker gets neither, since only the Humano key is set.
      expect(defenderReductionMultiplier({ ...base, attackerRace: 'player_doram', bonus })).toBe(1);
    });

    it('still stacks subrace_all onto a monster attacker, where the line does apply', () => {
      const bonus = { subrace_all: 25, subrace_demon: 10 };

      expect(defenderReductionMultiplier({ ...base, attackerRace: 'demon', bonus })).toBeCloseTo(0.65, 10);
    });

    it('dmg_taken_range (Gazeti) only applies to physical ranged hits', () => {
      const bonus = { dmg_taken_range: 20 };
      // physical + ranged → applies
      expect(defenderReductionMultiplier({ ...base, isRanged: true, bonus })).toBeCloseTo(0.8, 10);
      // physical + melee → no effect
      expect(defenderReductionMultiplier({ ...base, isRanged: false, bonus })).toBe(1);
      // magical ranged → no effect (physical-only)
      expect(defenderReductionMultiplier({ ...base, dmgType: 'magical', isRanged: true, bonus })).toBe(1);
    });
  });

  describe('defenderReductionSteps — one named step per applied category', () => {
    const base = { dmgType: 'physical' as const, attackerRace: 'player_human', attackerElement: 'neutral', attackerSize: 'm' as const, attackerType: 'normal' as const };

    it('emits only nonzero categories, named + keyed, factors multiplying to the combined value', () => {
      const steps = defenderReductionSteps({ ...base, bonus: { subrace_player_human: 10, subele_neutral: 20, dmg_taken_all: 5 } });
      expect(steps.map((s) => s.label)).toEqual(['Redução Humano', 'Redução Neutro', 'Redução plana']);
      // No `subrace_all` in the keys: that line is "todas as raças de monstros" and does
      // not cover a player attacker, so the drill-down must not offer it either.
      expect(steps.find((s) => s.label === 'Redução Humano')).toMatchObject({ keys: ['subrace_player_human'], factor: 0.9 });
      expect(steps.find((s) => s.label === 'Redução Neutro')).toMatchObject({ keys: ['subele_all', 'subele_neutral'], factor: 0.8 });
      const combined = steps.reduce((m, s) => m * s.factor, 1);
      expect(combined).toBeCloseTo(defenderReductionMultiplier({ ...base, bonus: { subrace_player_human: 10, subele_neutral: 20, dmg_taken_all: 5 } }), 10);
    });

    it('names the element by the attack element and the race by the attacker', () => {
      expect(defenderReductionSteps({ ...base, attackerElement: 'fire', bonus: { subele_fire: 15 } })[0].label).toBe('Redução Fogo');
      expect(defenderReductionSteps({ ...base, attackerRace: 'player_doram', bonus: { subrace_player_doram: 12 } })[0].label).toBe('Redução Doram');
    });

    it('keys the size step with the untyped pair plus the pair of the damage type', () => {
      const bonus = { subsize_m: 10, subsize_m_physical: 5 };
      expect(defenderReductionSteps({ ...base, bonus })).toMatchObject([
        {
          label: 'Redução Médio',
          keys: ['subsize_all', 'subsize_m', 'subsize_all_physical', 'subsize_m_physical'],
          factor: 0.85,
        },
      ]);
      expect(defenderReductionSteps({ ...base, dmgType: 'magical', bonus })).toMatchObject([
        { label: 'Redução Médio', keys: ['subsize_all', 'subsize_m', 'subsize_all_magical', 'subsize_m_magical'], factor: 0.9 },
      ]);
    });

    it('is empty when nothing applies', () => {
      expect(defenderReductionSteps({ ...base, bonus: {} })).toEqual([]);
    });

    it('emits the ranged step only for a ranged physical hit', () => {
      const bonus = { dmg_taken_range: 20 };
      expect(defenderReductionSteps({ ...base, isRanged: true, bonus })).toMatchObject([
        { label: 'Redução à distância', keys: ['dmg_taken_range'], factor: 0.8 },
      ]);
      expect(defenderReductionSteps({ ...base, isRanged: false, bonus })).toEqual([]);
    });
  });
});
