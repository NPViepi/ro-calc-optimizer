/**
 * The share-link bridge: the same token the web calculator reads from `/s/<token>/`.
 *
 * Both directions matter. Agents receive links people copied out of the browser, and
 * hand back links people open in it — so this module must stay byte-compatible with
 * `RoCalculatorComponent#buildShareUrl` / `#consumeSharedBuild`.
 */
import { CompareState } from 'src/app/core/compare-state';
import { decodeShared, encodeBuild } from 'src/app/core/share-codec';
import { isShortLink } from 'src/app/core/share-link-input';
import { buildSharePath, readShareToken } from 'src/app/core/share-path';
import { CharacterBase } from 'src/app/jobs/_character-base.abstract';
import { MainModel } from 'src/app/models/main.model';
import { toUpsertPresetModel } from 'src/app/utils';
import { CustomItemDefinition } from 'src/app/core/custom-items';

/** Legacy form, kept for links minted before the token moved into the path. */
const TOKEN_IN_URL = /[?&]b=([^&#\s]+)/;

export interface DecodedShare {
  preset: Record<string, any>;
  compare: CompareState | null;
  items?: CustomItemDefinition[];
}

/** Request-local access to the shortener Worker; omitted by Node callers. */
export interface Shortener {
  fetch(url: string, init: RequestInit): Promise<Response>;
}

/** A build as the app serializes it for saving/sharing. */
export const toPreset = (model: MainModel, char: CharacterBase): Record<string, any> =>
  toUpsertPresetModel(model, char) as unknown as Record<string, any>;

export const buildShareUrl = (preset: Record<string, any>, appOrigin: string, compare?: CompareState | null, items?: CustomItemDefinition[]): string =>
  `${appOrigin.replace(/\/+$/, '')}${buildSharePath(encodeBuild(preset, compare, items))}`;

/**
 * Accepts a full URL in either form (`/s/<token>/` or the legacy `#/?b=…`), a bare
 * fragment, or a bare token, and returns the sparse build plus any comparison it
 * carries. Throws on anything undecodable — an agent silently calculating a default
 * build from a typo'd link would be worse.
 */
export function parseShare(input: string): DecodedShare {
  const raw = (input ?? '').trim();
  if (!raw) throw new Error('Link de compartilhamento vazio.');

  const token = readShareToken(raw) ?? raw.match(TOKEN_IN_URL)?.[1] ?? raw;
  const decoded = decodeShared(token);
  if (!decoded) throw new Error('Link de compartilhamento inválido ou corrompido.');
  return decoded;
}

/** Expand a shortened link, or pass anything else through untouched. */
export const resolveIfShort = async (share: string, shortenerUrl: string, shortener?: Shortener): Promise<string> =>
  isShortLink(share, shortenerUrl) ? resolveShortLink(share, undefined, shortener) : share;

/**
 * Follow a short link to the real share URL. People paste the shortened form because
 * that's what the app's share dialog hands them.
 */
export async function resolveShortLink(url: string, timeoutMs = 3000, shortener?: Shortener): Promise<string> {
  // `redirect: 'manual'` is load-bearing for the legacy links already in the wild: their
  // token lives in the URL fragment, which fetch strips from `res.url` when it follows a
  // redirect — and once followed there is no Location header left to recover it from.
  const init: RequestInit = { redirect: 'manual', signal: AbortSignal.timeout(timeoutMs) };
  const res = await (shortener ? shortener.fetch(url, init) : fetch(url, init));
  const location = res.headers.get('location');
  const candidate = location ? new URL(location, url).href : res.url;
  if (!readShareToken(candidate) && !TOKEN_IN_URL.test(candidate)) {
    throw new Error(`O link curto ${url} não aponta para uma simulação.`);
  }
  return candidate;
}

/**
 * Shorten a build or custom-item URL via the same service the app uses. Best-effort: the long URL
 * always works, so a shortener hiccup must not fail the tool call.
 */
export async function shortenShareUrl(url: string, shortenerUrl: string, timeoutMs = 3000, shortener?: Shortener): Promise<string> {
  try {
    const endpoint = `${shortenerUrl}/api/links`;
    const init: RequestInit = {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(timeoutMs),
    };
    const res = await (shortener ? shortener.fetch(endpoint, init) : fetch(endpoint, init));
    if (!res.ok) return url;
    const body = (await res.json()) as { short_url?: string };
    return body?.short_url || url;
  } catch {
    return url;
  }
}
